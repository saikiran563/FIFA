import axios from 'axios';
let CQ_INFO =  {};
//For Contact
// const BASE_URL = "https://vzwqa2.verizonwireless.com/ui/acct/";
// const API_NAME = {
//   GET_CD_INFO: "secure/data/secure/profile/contactAndBillingInfo",
//   SET_EMAIL_INFO: "secure/data/secure/profile/emailAddress",
//   SET_PHONE_INFO: "secure/data/secure/profile/primaryPhone",
//   SET_BILL_ADDR_INFO: "secure/data/secure/profile/billingAddressInfo",
//   //    SET_SERV_ADDR_INFO:"serviceaddress"

//   //For Security
//   GET_CQ_INFO: "secure/account/get_cq_messages/ProfileSecurityDetails",
//   GET_META_INFO: "secure/data/secure/profile/securityInfo",
//   GET_BAN_PWD_INFO: "secure/data/secure/profile/bannedPasswords",
//   /* bannedpwd url */
//   GET_QUES_INFO: "secure/data/secure/profile/activeSecretQuestions",
//   /* activeSecretQuestions */
//   SET_QUES_INFO: "secure/data/secure/profile/secretQuestion",
//   SET_USER_INFO: "secure/data/secure/profile/userIdInfo",
//   SET_PIN_INFO: "ao/data/ao/profile/accPinInfo",
//   SET_PASSWORD_INFO: "secure/data/secure/profile/passInfo"
// }

// Contact & billing For local Dev
// const D_URL = "http://localhost:3000/"
// const DUMMY_API_NAME =  {
//    GET_CD_INFO: "contact",
//    SET_EMAIL_INFO: "email",
//    SET_PHONE_INFO:"primaryphone",
//    SET_BILL_ADDR_INFO:"billingaddress",
//    SET_SERV_ADDR_INFO:"serviceaddress"

//  }

// Security For local Dev
// http://www.mocky.io/v2/5b4f59783200005a009c2e92

 const D_URL = "http://www.mocky.io/v2/5b64bb432e0000063e414168"; 
 const DUMMY_API_NAME =  {
    GET_META_INFO:"",
    SET_USER_INFO:"",
    SET_PIN_INFO:"",
    GET_QUES_INFO: "",
    GET_CQ_INFO:"",
    GET_BAN_PWD_INFO:""
 }

export function encrypt(str){
    return btoa(str);
}
export function decrypt(str){
    return atob(str);
}

export function getURL(api) {
//  return BASE_URL + API_NAME[api];
  return D_URL + DUMMY_API_NAME[api];
}


function getCqData() { 
    axios.get(getURL("GET_CQ_INFO"))
      .then((response) => {
     /* response.data = {
        errorCode_5881:"validation error",
        errorCode_5883:"user name not available"
      }*/
       CQ_INFO = response.data; 
      })
       .catch((err) => {
          CQ_INFO = {}
       })
  }
  
  export  function getErrorMsgByCode(errorCode) {
      return  CQ_INFO[`errorCode_${errorCode}`];
  }
  
  getCqData();
