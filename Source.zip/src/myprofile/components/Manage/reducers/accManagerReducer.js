import {
  FETCH_MANAGE_LANDING_BEGIN,
  FETCH_MANAGE_LANDING_SUCCESS,
  FETCH_MANAGE_LANDING_FAIL,
  FETCH_MTNS_SUCCESS,
  FETCH_MANAGER_REQUESTS_SUCCESS,
  GET_ACCOUNT_MEMBER_DETAILS_SUCCESS,
  ADD_NEW_MANAGER_SUCCESS,
  ADD_NEW_MANAGER_FAIL,
  SHOW_LEARN_MORE_POPUP,
  HIDE_LEARN_MORE_POPUP,
  APPROVE_MANAGER_SUCCESS,
  APPROVE_MANAGER_FAIL,
  CLEAR_ERROR_CODES
} from '../actions/manage'

const initialState = {
  managers: [],
  addedManager: [],
  revokedManager: {},
  accountManagerRequests: [],
  mtns: [],
  emailId: '',
  phoneNumber:'',
  deniedAccountManagerRequests: null,
  showRequestSuccessPopup: false,
  showSpinner: true,
  newAccountMemberRequest:  {
      status: 'not requested' // other Status:  request pending , request denied
  },
  showLearnMorePopUp: false,
  approveManagerError: "",
  addManagerError: ""
}

import {
  createReducer,
  updateObject,
  updateItemInArray,
} from '../../../../utils/reducer'

const accManagerReducer = (state = initialState, action) => {
  const { type } = action
  switch (type) {
    case CLEAR_ERROR_CODES:
      return {
        ...state,
        approveManagerError: "",
        addManagerError: ""
      }
    case ADD_NEW_MANAGER_SUCCESS:
      console.log("Add account manager reducer",action)
      return {
        ...state,
        managers: [...state.managers, action.response.data],
        addedManager: action.response.data,
        addManagerError: ""
      }
    case ADD_NEW_MANAGER_FAIL:
      console.log("ADD_NEW_MANAGER_FAIL", action)
      return {
        ...state,
        addManagerError: action.error
      }
    case APPROVE_MANAGER_SUCCESS:
      console.log("APPROVE_MANAGER_SUCCESS", action)
      return {
        ...state,
        managers: [...state.managers, action.response.data],
        accountManagerRequests: [...state.accountManagerRequests.filter(accountMember => accountMember.phoneNumber != action.response.data.phoneNumber)],
        approveManagerError: ""
      }
    case APPROVE_MANAGER_FAIL:
    console.log("APPROVE_MANAGER_FAIL", action)
     return {
       ...state,
       approveManagerError: action.error
     }
    case FETCH_MANAGE_LANDING_BEGIN:
      return updateObject(state, {
        showSpinner: true
      })

    case FETCH_MANAGE_LANDING_SUCCESS:
      return updateObject(state, {
        managers: action.response.customerInfo,
        showSpinner: false
      })

    case FETCH_MTNS_SUCCESS:
      return updateObject(state, {
        mtns: action.response.mtnList
    })

    case FETCH_MANAGER_REQUESTS_SUCCESS:
      let accountManagerRequests = []
      action.response.customerInfo.forEach(eachManager => {
        if( eachManager.role === 'mobileSecure' ){
          accountManagerRequests.push(eachManager)
        }
      })
      return updateObject(state, {
        accountManagerRequests
      })
    case GET_ACCOUNT_MEMBER_DETAILS_SUCCESS :
    return updateObject(state, {
      emailId: action.response.emailId,
      phoneNumber: action.response.phoneNumber,
      newAccountMemberRequest : {
        status: action.response.hasPendingRequests ? 'request pending' : 'not requested'
      }
    })
    case SHOW_LEARN_MORE_POPUP:
      return updateObject(state, {
        showLearnMorePopUp: true
    })
    case HIDE_LEARN_MORE_POPUP:
      return updateObject(state, {
        showLearnMorePopUp: false
    })
    default:
      return state
  }
}

export default accManagerReducer
