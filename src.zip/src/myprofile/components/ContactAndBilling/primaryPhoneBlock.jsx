import React, { Component } from "react";
import InputField from "../FormElements/InputComponent";
import { getErrorMsgByCode } from "../../../utils/config";
import { connect } from "react-redux";
import Modal from "../Modal/modal";
import SecurePin from "../SecurePin/SecurePin";
import {
  getSecretPinStatus,
  getListOfUserNumbers,
  clearErrorCodes
} from "../Security/actions/fetchSecurities";
import { clearContactAndBillingCodes } from "./actions/setEmailid"

class PrimaryPhoneBlock extends Component {
  constructor(props) {
    super(props);
    this.state = {
      userPrimaryPhone: this.convertPhoneToUSAFormat(
        this.props.userPrimaryPhoneInfo.primaryPhone
      ),
      userAlternatePhone: this.convertPhoneToUSAFormat(
        this.props.userPrimaryPhoneInfo.alternatePhone
      ),
      requiredPrimaryError: true,
      requiredAlternateError: true,
      isValidPrimary: false,
      isValidAlternate: false,
      istouchedPrimary: false,
      istouchedAlternate: false,
      modalStatus: false,
      errorModal: false,
      phoneidInvalidMessages: [
        { name: "Invalid phone number", error: false, type: "number" }
      ]
    };
  }
  componentWillReceiveProps(newProps) {
    if (
      newProps.userPrimaryPhoneInfo.primaryPhone !==
        this.props.userPrimaryPhoneInfo.primaryPhone ||
      newProps.userPrimaryPhoneInfo.alternatePhone !==
        this.props.userPrimaryPhoneInfo.alternatePhone
    ) {
      this.setState({
        userPrimaryPhone: this.convertPhoneToUSAFormat(
          newProps.userPrimaryPhoneInfo.primaryPhone
        ),
        userAlternatePhone: this.convertPhoneToUSAFormat(
          newProps.userPrimaryPhoneInfo.alternatePhone
        )
      });
    }
    if(this.props.primaryPhoneStatus){
      if(newProps.event !== this.props.event){
        this.props.clearContactAndBillingCodes()
      }
    }
  }
  handleOnChange = e => {
    let x = e.target.value
      .replace(/\D/g, "")
      .match(/(\d{0,3})(\d{0,3})(\d{0,4})/);
    let value = !x[2]
      ? x[1]
      : "" + x[1] + "." + x[2] + (x[3] ? "." + x[3] : "");

    this.setState({ userPrimaryPhone: value }, () => this.onChangeInput());
  };

  convertPhoneToUSAFormat = phone => {
    let x = phone.replace(/\D/g, "").match(/(\d{0,3})(\d{0,3})(\d{0,4})/);
    return !x[2] ? x[1] : "" + x[1] + "." + x[2] + (x[3] ? "." + x[3] : "");
  };

  handleOnAlternatePhoneChange = e => {
    let x = e.target.value
      .replace(/\D/g, "")
      .match(/(\d{0,3})(\d{0,3})(\d{0,4})/);
    let value = !x[2]
      ? x[1]
      : "" + x[1] + "." + x[2] + (x[3] ? "." + x[3] : "");

    this.setState({ userAlternatePhone: value }, () =>
      this.onChangeAlternatePhoneInput()
    );
  };

  handleOnEditCancel = type => {
    this.setState({
      userPrimaryPhone: this.convertPhoneToUSAFormat(
        this.props.userPrimaryPhoneInfo.primaryPhone
      ),
      userAlternatePhone: this.convertPhoneToUSAFormat(
        this.props.userPrimaryPhoneInfo.alternatePhone
      )
    });
    this.props.handleEditCancel(type);
  };

  onChangeInput = () => {
    this.setState({ istouchedPrimary: true });
    const val = this.state.userPrimaryPhone;
    const phoneidInvalidMessages = JSON.parse(
      JSON.stringify(this.state.phoneidInvalidMessages)
    );
    if (
      /\d{3}[\.]\d{3}[\.]\d{4}/.test(val) &&
      val !==
        this.convertPhoneToUSAFormat(
          this.props.userPrimaryPhoneInfo.primaryPhone
        )
    ) {
      let testAlternate = false;
      if (
        /\d{3}[\.]\d{3}[\.]\d{4}/.test(this.state.userAlternatePhone) ||
        this.state.userAlternatePhone === ""
      ) {
        testAlternate = true;
      }
      this.setState({
        requiredPrimaryError: false,
        isValidPrimary: true,
        isValidAlternate: testAlternate
      });
    } else {
      this.setState({
        requiredPrimaryError: true,
        isValidPrimary: false,
        phoneidInvalidMessages: [
          {
            name: "Not a valid phone number format",
            error: false,
            type: "character"
          }
        ]
      });
    }
  };

  closeModal = () => {
    this.props.clearErrorCodes();
    this.setState({
      modalStatus: false,
      errorModal: false
    });
  };
  saveChangesClickedHandler = () => {
    this.props.getSecretPinStatus().then(() => {
      const { securePin } = this.props;
      console.log(securePin);
      if (!this.props.securePinError) {
        if (!securePin.securePinEnabled) {
          console.log("secure pin not enabled");
          return this.props.handleSave(
            "primaryPhoneBlock",
            {
              primaryPhone: this.state.userPrimaryPhone.split(".").join(""),
              alternatePhone: this.state.userAlternatePhone.split(".").join("")
            },
            event
          );
        }
        if (!securePin.securePinVerified) {
          console.log("secure pin not verified, go through secure pin flow");
          this.props.getListOfUserNumbers().then(() => {
            this.setState({
              modalStatus: true
            });
          });
        } else {
          console.log("secure pin already verified");
          return this.props.handleSave(
            "primaryPhoneBlock",
            {
              primaryPhone: this.state.userPrimaryPhone.split(".").join(""),
              alternatePhone: this.state.userAlternatePhone.split(".").join("")
            },
            event
          );
        }
      } else {
        this.setState({
          errorModal: true
        });
      }
    });
  };

  onChangeAlternatePhoneInput = () => {
    this.setState({ istouchedAlternate: true });
    const val = this.state.userAlternatePhone;
    const phoneidInvalidMessages = JSON.parse(
      JSON.stringify(this.state.phoneidInvalidMessages)
    );
    if (
      (/\d{3}[\.]\d{3}[\.]\d{4}/.test(val) || val === "") &&
      val !==
        this.convertPhoneToUSAFormat(
          this.props.userPrimaryPhoneInfo.alternatePhone
        )
    ) {
      let testPrimary = false;
      if (
        /\d{3}[\.]\d{3}[\.]\d{4}/.test(this.state.userPrimaryPhone) ||
        this.state.alternatePhone === ""
      ) {
        testPrimary = true;
      }
      this.setState({
        requiredAlternateError: false,
        isValidAlternate: true,
        isValidPrimary: testPrimary
      });
    } else {
      this.setState({
        requiredAlternateError: true,
        isValidAlternate: false,
        phoneidInvalidMessages: [
          {
            name: "Not a valid phone number format",
            error: false,
            type: "character"
          }
        ]
      });
    }
  };

  render() {
    const {
      phoneidInvalidMessages,
      requiredPrimaryError,
      requiredAlternateError,
      userPrimaryPhone,
      userAlternatePhone
    } = this.state;
    const {
      userPrimaryPhoneInfo,
      showPrimaryPhoneEdit,
      primaryPhoneEditMode,
      primaryPhoneStatus
    } = this.props;
    const isValidPrimary = this.state.isValidPrimary;
    const isValidAlternate = this.state.isValidAlternate;
    const editableClassName = primaryPhoneEditMode
      ? ""
      : "description_box_disabled";
    const savedSectionStyle = {
      display: "inline",
      "margin-top": "10px",
      "padding-top": "10px"
    };
    let isEditActive = !showPrimaryPhoneEdit && primaryPhoneEditMode;
    if (primaryPhoneStatus && primaryPhoneStatus !== "0") {
      isEditActive = true;
    }
    return (
      <div className={`row description_box ${editableClassName}`}>
        <div className="clearfix" />
        <div className="body">
          <div className="col-xs-12 col-sm-4 description_box__header">
            <h4 tabIndex="0">Contact Numbers</h4>
            <p>Provide the phone numbers where we can best reach you.</p>
          </div>
          <div className="col-xs-12 col-sm-8 description_box__large-container">
            <div className="row">
              <div className="col-xs-12 col-sm-8 description_box__details">
                {!isEditActive && (
                  <div className="description_box__read">
                    <p>{this.convertPhoneToUSAFormat(userPrimaryPhone)}</p>
                  </div>
                )}
                {isEditActive && (
                  <div className="description_box__form">
                    <div className="row">
                      <div className="col-xs-12">
                        <div className="form-group phone-block-input">
                          <label htmlFor="primary phone number">
                            Primary Phone
                          </label>
                          <InputField
                            type="text"
                            handleOnChange={this.handleOnChange}
                            placeholder="000.000.0000"
                            name="primaryphone"
                            pattern="^\d{3}.\d{3}.\d{4}$"
                            touched={this.state.istouchedPrimary}
                            value={userPrimaryPhone}
                            analyticstrack="primaryPhone-inputfield"
                          />
                        </div>

                        <div className="form-group phone-block-input">
                          <label htmlFor="alternate phone number">
                            Alternate Phone
                          </label>
                          <InputField
                            type="text"
                            handleOnChange={this.handleOnAlternatePhoneChange}
                            placeholder="000.000.0000"
                            name="alternatephone"
                            touched={this.state.istouchedAlternate}
                            value={userAlternatePhone}
                            analyticstrack="alternativePhone-inputfield"
                          />
                        </div>
                        {this.props.primaryPhoneFailure ? (
                          <span className="help-block help-block-error">
                            <p className="errorDisplay">
                              <span className="fa fa-exclamation-circle" />
                              {getErrorMsgByCode(this.props.primaryPhoneFailure)}
                            </p>
                          </span>
                        ) : null}
                      </div>
                      {isEditActive && (
                        <div className="footer description_box__control-btn col-xs-12">
                          <button
                            className="btn btn--round-invert"
                            role="button"
                            onClick={() =>
                              this.handleOnEditCancel("cancelBlock")
                            }
                            analyticstrack="primaryPhone-cancel"
                          >
                            Cancel
                          </button>
                          <button
                            className="btn btn--round"
                            disabled={
                              !(isValidPrimary && isValidAlternate) ||
                              reactGlobals.isCsr
                            }
                            onClick={this.saveChangesClickedHandler}
                            analyticstrack="primaryPhone-savechanges"
                          >
                            Save Changes
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
              {primaryPhoneStatus == "0" && (
                <span
                  className="text-success fa fa-check-circle col-xs-12 section-saved section-saved_block"
                  tabIndex="0"
                  style={savedSectionStyle}
                >
                  &nbsp;Saved
                </span>
              )}
              {showPrimaryPhoneEdit && (
                <div className="description_box__edit description_box__edit_section primary-phone-edit">
                  <a
                    className="description_box__btn-edit"
                    onClick={() =>
                      this.props.handleEditCancel("primaryPhoneBlock")
                    }
                    role="button"
                    analyticstrack="primaryPhone-edit"
                  >
                    Edit
                  </a>
                </div>
              )}
              {isEditActive && (
                <div className="description_box__edit description_box__edit_section primaryPhone_cancel cancel">
                  <a
                    className="description_box__btn-edit description_box__btn-edit-cancel"
                    onClick={() => this.props.handleEditCancel("cancelblock")}
                    role="button"
                    analyticstrack="primaryPhone-cancel"
                  >
                    Cancel
                  </a>
                </div>
              )}
            </div>
          </div>
        </div>
        <Modal
          modalStatus={this.state.modalStatus}
          closeModal={this.closeModal}
        >
          <SecurePin
            handleSaveType="primaryPhoneBlock"
            handleSaveData={{
              primaryPhone: this.state.userPrimaryPhone.split(".").join(""),
              alternatePhone: this.state.userAlternatePhone.split(".").join("")
            }}
            closeModal={this.closeModal}
            handleSave={this.props.handleSave}
          />
        </Modal>

        <Modal modalStatus={this.state.errorModal} closeModal={this.closeModal}>
          {getErrorMsgByCode(this.props.securePinError)}
        </Modal>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    securePin: state.security.secretPin,
    securePinError: state.security.securePinError,
    primaryPhoneFailure: state.contactDetails.primaryPhoneFailure
  };
};

export default connect(
  mapStateToProps,
  {
    getSecretPinStatus,
    getListOfUserNumbers,
    clearErrorCodes,
    clearContactAndBillingCodes
  }
)(PrimaryPhoneBlock);
