import axios from 'axios';
import { getURL } from '../../../../utils/config';

export const SET_BILLING_ADDRESS = 'contacts/SET_BILLING_ADDRESS'
export const SET_BILLING_ADDRESS_SUCCESS = 'contacts/SET_BILLING_ADDRESS_SUCCESS'
export const SET_BILLING_ADDRESS_ERROR = 'contacts/SET_BILLING_ADDRESS_ERROR'
export const FETCH_CONTACT_AND_BILLING_BEGIN = 'contacts/FETCH_CONTACT_AND_BILLING_BEGIN'
export const USER_NOT_VERIFIED = "USER_NOT_VERIFIED"


import {contents} from './verifyModalContent'

export const setBillingAddress = (address) => dispatch => {



          //  dispatch(showVerifyAddressModal());
            
           // dispatch(showVerifiedAddress(contents));

    // API CAll WILL BE CALLED HERE
   // axios.post("http://localhost:3000/contact",{data: id})
    // .then((response) => {
     ///   dispatch(getBillingAddressSuccess(response));
        // if('address is not verified'){
        //     dispatch(showVerifyAddressModal());
        //     dispatch(showVerifiedAddress(response));
        // } 
     // })
     // .catch((err) => {
      //  dispatch(getBillingAddressError(err))
     // })
}
export const showVerifiedAddress = (contents) => ({
   type: 'modal/SET_MODAL_CONTENT',
  contents,
});
export const showVerifyAddressModal = () => ({
 type: 'modal/SHOW_MODAL',
});

// export const getBillingAddressSuccess = (response) => ({
//   type: SET_BILLING_ADDRESS_SUCCESS,
//   response,
// })
// export const getBillingAddressError = (error) => ({
//   type: SET_BILLING_ADDRESS_ERROR,
//   error,
// })

export const setBillingAddressSuccess = (response) => ({
  type: SET_BILLING_ADDRESS_SUCCESS,
  status: response,
})
export const setBillingAddressError = (response) => ({
  type: SET_BILLING_ADDRESS_ERROR,
  status: response,
})

export const setBillingAddressOnSuccess = (response) => ({
  type: SET_BILLING_ADDRESS,
  response,
})

export const showLoader = () => ({
  type: FETCH_CONTACT_AND_BILLING_BEGIN
})

export const updateBillingAddress = address => async dispatch => {
  // API CAll WILL BE CALLED HERE
  dispatch(showLoader());

  const response = await axios({
    method: "post",
    url: getURL('SET_BILL_ADDR_INFO'),
    timeout: 30000, // Let's say you want to wait at least 30 secs
    data: address
  }).catch(err => {
    dispatch(setBillingAddressError(err));
  });

  // response.data.data = {};
  // response.data.data.statusCode = "0";
  // response.data.securePinVerified = false;
  // response.data.errorCode = "123"

  if(response){
    if (
      response.data.securePinVerified === undefined ||
      response.data.securePinVerified === null
    ) {
      if (response.data.hasOwnProperty("data")) {
        if (response.data.data.hasOwnProperty("statusCode")) {
          if (response.data.data.statusCode == 0) {
            dispatch(setBillingAddressOnSuccess(address));
            dispatch(setBillingAddressSuccess(response.data.data.statusCode));
          } else {
            dispatch(setBillingAddressError(response.data.errorCode));
          }
        } else {
          dispatch(setBillingAddressError("error"));
        }
      } else {
        dispatch(setBillingAddressError("error"));
      }
    } else {
      dispatch({
        type: USER_NOT_VERIFIED
      });
    }
  } else {
    dispatch(setBillingAddressError("error"))
  }

  // if (response.data.data.statusCode == 0) {
  //   if (
  //     response.data.data.securePinVerified === undefined ||
  //     response.data.data.securePinVerified === null
  //   ) {
  //   dispatch(setBillingAddressOnSuccess(address));
  //   dispatch(setBillingAddressSuccess(response.data.data.statusCode));
  //   } else {
  //     dispatch({
  //       type: USER_NOT_VERIFIED
  //     });
  //   }
  // } else {
  //   dispatch(setBillingAddressError(response.data.errorCode));
  // }
};

export const resetBillingAddressStatus = (response) => dispatch => {
  dispatch({
    type: SET_BILLING_ADDRESS_SUCCESS,
             status: response
  } )
}


