import axios from 'axios';
import { getURL } from '../../../../utils/config';

export const SET_PRIMARY_PHONE = 'contacts/PRIMARY_PHONE'
export const SET_PRIMARY_PHONE_SUCCESS = 'contacts/SET_PRIMARY_PHONE_SUCCESS'
export const SET_PRIMARY_PHONE_ERROR = 'contacts/SET_PRIMARY_PHONE_ERROR'
export const FETCH_CONTACT_AND_BILLING_BEGIN = 'contacts/FETCH_CONTACT_AND_BILLING_BEGIN'
export const USER_NOT_VERIFIED = "USER_NOT_VERIFIED";


export const getPrimaryPhoneSuccess = (response) => ({
  type: SET_PRIMARY_PHONE_SUCCESS,
  status : response,
});

export const setPrimaryPhoneOnSuccess = (response) => ({
   type: SET_PRIMARY_PHONE,
  response,
});

export const getPrimaryPhoneError = (response) => ({
  type: SET_PRIMARY_PHONE_ERROR,
  status: response,
})

export const resetPrimaryPhoneStatus = (response) => dispatch => {
  dispatch({
    type: SET_PRIMARY_PHONE_SUCCESS,
             status : response
  } )
}

export const showLoader = () => ({
  type: FETCH_CONTACT_AND_BILLING_BEGIN
})

export const setPrimaryPhone = data => async dispatch => {
  // API CAll WILL BE CALLED HERE
  // "http://www.mocky.io/v2/5b69e4b83200003715af5e96"
  // getURL('SET_PHONE_INFO')
  dispatch(showLoader());
  const response = await axios({
    method: "post",
    url: getURL('SET_PHONE_INFO'),
    timeout: 30000, // Let's say you want to wait at least 30 secs
    data: data
  }).catch(err => {
    dispatch(getPrimaryPhoneError(err));
  });

  // response.data.data = {};
  // response.data.data.statusCode = "0";
  // response.data.errorCode = "123"
  // debugger;

  if (response.data.data.statusCode == 0) {
    if (
      response.data.data.securePinVerified === undefined ||
      response.data.data.securePinVerified === null
    ) {
    dispatch(getPrimaryPhoneSuccess(response.data.data.statusCode));
    dispatch(setPrimaryPhoneOnSuccess(data));
    } else {
      dispatch({
        type: USER_NOT_VERIFIED
      });
    }
  } else {
    dispatch(getPrimaryPhoneError(response.data.errorCode));
  }
};



