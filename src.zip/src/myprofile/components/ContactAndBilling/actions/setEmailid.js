import axios from 'axios';
import { getURL } from '../../../../utils/config';

export const SET_EMAILID = 'contacts/SET_EMAILID'
export const SET_EMAILID_SUCCESS = 'contacts/SET_EMAILID_SUCCESS'
export const SET_EMAILID_ERROR = 'contacts/SET_EMAILID_ERROR'
export const CLEAR_CONTACT_AND_BILLING_CODES = "CLEAR_CONTACT_AND_BILLING_CODES"

export const clearContactAndBillingCodes = () => dispatch => {
  dispatch({
    type: CLEAR_CONTACT_AND_BILLING_CODES
  })
}

export const setEmailId = (data) => dispatch => {
    // API CAll WILL BE CALLED HERE
    // "http://www.mocky.io/v2/5b800c353400004d00dc0707"
    // getURL('SET_EMAIL_INFO')
    axios({
        method: 'post',
        url: getURL('SET_EMAIL_INFO'),
        timeout: 30000, // Let's say you want to wait at least 30 secs
        data: data
    })
      .then((response) => {
        // response.data.statusCode = "0"
        // response.errorCode = "5889"
        if(response.data.statusCode == 0){
          dispatch(setEmailIdonSuccess(data));
          dispatch(getEmailIdSuccess(response.data.statusCode))
          
        }else{
          dispatch(getEmailIdError(response.errorCode))
        }

        // // dispatch(setEmailIdonSuccess(data));
        //   dispatch(getEmailIdError('0'))
        
      })
      .catch((err) => {
        dispatch(getEmailIdError(err))
      })
}

export const getEmailIdSuccess = (response) => ({
  type: SET_EMAILID_SUCCESS,
  status : response,
});

export const resetEmailStatus = (response) => dispatch => {
  dispatch({
    type: SET_EMAILID_SUCCESS,
  status : response,
  } )
}

export const setEmailIdonSuccess = (response) => ({
  type: SET_EMAILID,
  response
});

export const getEmailIdError = (response) => ({
  type: SET_EMAILID_ERROR,
  status: response,
})

