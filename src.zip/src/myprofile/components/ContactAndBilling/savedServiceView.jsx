import React from 'react'

class SavedView extends React.Component {
    state = {
        on: false
    }
    toggle = () => {
        this.setState({ on: !this.state.on })
    }

    componentDidMount() {
      //  setTimeout(this.toggle, 8000)
    }

    // call the `toggle` function after 5000ms

    render() {
        const {styleTag, classTag} =  this.props;
        if (!this.state.on) {
            return (<span
                className={classTag}
                tabIndex="0"
                style={styleTag}
                >
                &nbsp;Saved
            </span>
            )
        }
        else {
            return (
                null
            )
        }
    }
}
export default SavedView;