﻿import React, { Component } from 'react';
import Spinner from "../../Spinner/Spinner"

class RevokeAccess extends Component {
    render() {
      const closePadding = { 'padding-left': "16px", 'padding-right': "16px" }
        return (
          <div id="overlayFrameacctmanagement-revokeaccess" className="animated fadeIn a-fast">
          <div className="modal_content">
              <span className='title title--lg'>
                Are you sure you want to remove this Account Manager - yes ?
              </span>
              <br aria-hidden="true" />
              <br aria-hidden="true" />
              <div className='revoke-popup-seperator'/>
              <div className='revoke-popup-body'>
                <p>
                Once removed, this person will no longer be able to make changes to the account’s lines and information.
                </p>
              </div>
              <div className='row'>
              <div className='col-xs-6 col-sm-6 pl-0'>
              <button className="btn btn--round-invert pull-right" onClick={(e) => this.props.onClosePopup()} analyticstrack="accountmanager-cancel">Cancel</button>
                  </div>
                  <div className='col-xs-6 col-sm-6 plr-0'>
              <button className="btn btn--round pull-left" style={closePadding} onClick={this.props.handleRevokeAccess} analyticstrack="accountmanager-remove">Remove manager</button>
                  </div>
              </div>
          </div>
          {this.props.showSpinner ? <Spinner /> : ""}
          </div>
        )
    }
}

export default RevokeAccess
