﻿import React from "react";

const TermsAndCoditions = (props) => {
  console.log("Sai Kiran",props.newManagerDetails)
  return (
    <div id="overlayFrame acctmanagement-accessroles" className="animated fadeIn a-fast">
    <div className="modal_content">
      <h1 className="title title--lg">Account Managers</h1>
      <br aria-hidden="true" />
      <br aria-hidden="true" />
      <h2>Review and Accept Terms and Conditions</h2>
      <br/>
      <p>Please read the Account Manager Authorization Terms and Conditions. Select the “Continue” button below to process your request.</p>
      <br/>
      <p>You have requested the following Account Manager(s) be added to your wireless account. You confirm that the requested Account Manager(s) is/are at least 18 years of age and you authorize the requested Account Manager(s) to enter into contracts and perform all transactions regarding your account, except those transactions excluded below.</p>
      <br/>
      <div>
      <h2>{props.newManagerDetails.firstName}   {props.newManagerDetails.lastName}     {props.newManagerDetails.phoneNumber}</h2>
      </div>
      <br/>
      <p>You accept that you will be responsible for all changes made to your account(s) by the Account Manager(s).</p>
      <br/>
      <p>You are responsible for providing the Account PIN to each Account Manager. Account Managers must know the Account PIN in order to access information or perform transactions on the account.</p>
      <br/>
      <p>Please carefully review the Account Manager’s authority below prior to accepting.</p>
      <br/>
      <h2>Account Manager’s Authority</h2>
      <br/>
      <p>Account Managers may perform all the same transactions as the Account Owner, online, in retail locations, and by calling Customer Service, EXCEPT for the following:</p>
      <br/>
      <p>•  Add, Change, or delete Account PIN.</p>
      <p>•  Add, Change, or delete other Account Managers.</p>
      <br/>
      <br aria-hidden="true" />
      <br aria-hidden="true" />
      <div className="rol-permissions__buttons">
      <div className="col-xs-12">
        <button className="btn btn--round-invert btnclose" onClick={(e) =>props.onClosePopup(e)}>Close</button>
        <button className="btn btn--round btnclose"
                style={{'width':'95px','text-decoration':'none'}}
                role="button"  onClick={(e) =>props.onContinue(e)}>Continue</button>
    </div>
    </div>
    </div>
    </div>
  );
};

export default TermsAndCoditions;
