import React, { Component } from 'react'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import * as actions from './actions'
import InputField from '../FormElements/InputComponent'
import './style.css'

class PreferenceCenter extends Component {  
  render() {
    const { showPreferenceCenterEdit, preferenceCenterEditMode } = this.props;
    const editableClassName = preferenceCenterEditMode ? "description_box--edit-view" : "description_box_disabled";
    return (
        <div className={`row description_box ${editableClassName}`}>
        <div className="clearfix"></div>
        <div className="body row">
          <div className="col-xs-12 col-sm-4 description_box__header">
            <h4 tabIndex="1">Preference center </h4>
            <p>Change who gets what alerts, and manage notifications about your billing, data use, shipping and more.  </p>
          </div>
          {
            showPreferenceCenterEdit && (
              <div>
                  <div className="col-xs-12 col-sm-4">
                  </div>
                  <div className="col-xs-12 col-sm-4 transferofservice-cont">
                    <a
                      className="btn btn--round-invert"
                      role="button"
                      href='https://wbillpay.verizonwireless.com/vzw/accountholder/alerts/home.action'
                      analyticstrack="Manageaccount-Preferencecenter">
                      Preference Center 
                    </a>
                  </div>
              </div>
            )
          }
          {
            !showPreferenceCenterEdit && preferenceCenterEditMode && (
            <div>
                <div className="col-xs-12 col-sm-4">
                </div>
                {
                  reactGlobals.role.toLocaleLowerCase() !="mobilesecure" &&
                  <div className="col-xs-12 col-sm-4 transferofservice-cont">
                    <a
                      className="btn btn--round-invert"
                      role="button"
                      href='https://wbillpay.verizonwireless.com/vzw/accountholder/alerts/home.action'
                      analyticstrack="Manageaccount-Preferencecenter">
                      Preference Center 
                    </a>
                  </div>
                }
            </div>
            )
          }

        </div>
      </div>
    )
  }
}

export default PreferenceCenter;
