﻿import React, { Component } from 'react'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import * as actions from './actions'
import InputField from '../FormElements/InputComponent'
import './style.css'
import './accountmanager.css'
import Popup from './Popup/Popup'
import RevokeAccess from './Popup/RevokeAccess'
import RequestSent from './Popup/RequestSent'
import AccessRoles from './Popup/AccessRoles'
import TermsAndConditions from './Popup/TermsAndConditions'
import ManagersListToAccountManager from './components/ManagersListToAccountManager'
import ManagerCard from './components/ManagerCard'
import { MAXIMUM_ACCOUNT_MANAGERS_ACTIVE } from './constants'
import formatPhoneNumber from './utilities/formatPhoneNumber'
import Modal from "../Modal/modal"
import SecurePin from "../SecurePin/SecurePin"
import { getErrorMsgByCode } from "../../../utils/config"
import Spinner from "../Spinner/Spinner"
const accountOwner = reactGlobals.mdnRole == 'accountHolder'
const accountMember = reactGlobals.mdnRole == 'mobileSecure'
const accountManager = reactGlobals.mdnRole == 'accountManager'

class AccountManagerBlock extends Component {
  constructor(props) {
    super(props)
    this.state = this.getinitialState()
  }

  getinitialState() {
    return {
      firstName: '',
      lastName: '',
      phoneNumber: this.props.memberPhoneNumber,
      emailId: this.props.memberEmailId,
      encryptedPhoneNumber: this.props.encryptedPhoneMem,
      showPopup: false,
      managerToRemove: {},
      isEditEmailOnAccountMemberSelected: false,
      showLearnMorePopUp: this.props.showLearnMorePopUp,
      showTCPopUp: false,
      moveCancelButton: 0,
      approveManagerSecurePinModalStatus: false,
      addManagerSecurePinModalStatus: false,
      listOfAccountNumbersModal: true,
      afterGetRequest: this.props.listOfUserNumbers,
      errorModal: false,
      approvedRequest: null,
      securePinError: false,
      fetchingSecurePin: false,
      managersChanged: false,
      amgrCount: 0,
      removeManagerSecurePin: false,
    }
  }

  getNewManagerDetails(){
    return{
      firstName: this.state.firstName,
      lastName: this.state.lastName,
      phoneNumber: this.state.phoneNumber,
      emailId: this.state.emailId
    }
  }
  saveChangesClickedHandler = (handleSaveType, approveData) => {
    this.props.actions.clearAccountManagerErrorCodes()
    this.props.actions.clearErrorCodes()

    const postData = {
      ...approveData,
      encryptedMdn: approveData ? approveData.phoneNumber === "Not Applicable" ? "Not Applicable" : this.props.mtns.find(number => number.mdn === approveData.phoneNumber).encryptedMdn : ""
     }
    
    let handleSaveFunction;
    if (handleSaveType === "approveAccountManagerBlock" ){
      handleSaveFunction = () => this.props.actions.postApproveManagerByAccountHolder(postData)
    } else if (handleSaveType === "accountmanagerBlock"){
      handleSaveFunction = () => this.props.actions.postAddManagerByAccountHolder(postData)
    } else {
      handleSaveFunction = () => this.props.actions.postRemoveManagerByAccountHolder(this.state.managerToRemove)
    }

    this.setState({ fetchingSecurePin: true, approveData: approveData ? postData : "" });

      handleSaveFunction()
        .then(() => {
          if (!this.props.addManagerError || !this.props.approveManagerError) {
            if (this.props.userVerified === false) {
              this.props.actions.getListOfUserNumbers().then(() => {
                this.setState({ fetchingSecurePin: false });
                if (handleSaveType === "approveAccountManagerBlock") {
                  this.props.actions.updateTagId("acctmanagersapprove-securepin")
                  this.setState({
                    approveManagerSecurePinModalStatus: true
                  });
                } else if (handleSaveType === "accountmanagerBlock"){
                  this.props.actions.updateTagId("acctmanagers-securepin")
                  this.setState({
                    addManagerSecurePinModalStatus: true
                  });
                } else {
                  this.props.actions.updateTagId("acctmanagersremove-securepin")
                  this.setState({
                    removeManagerSecurePin: true,
                    showPopup: false
                  })
                }
              });
            } else {
              this.setState({
                fetchingSecurePin: false,
                showPopup: false
              });
            }
          } else {
            this.setState({
              fetchingSecurePin: false,
              errorModal: true
            });
          }
    })
  };

  // startSecurePin = (event, payload, actionType) => {
  //   this.props.actions.clearAccountManagerErrorCodes()
  //   this.props.actions.clearErrorCodes()
  //   this.setState({
  //     fetchingSecurePin: true
  //   })
  //   if (actionType === 'approval') {
  //     this.handleAppproveAccountManagerRequest(payload)
  //   }
  //   this.props.actions.getSecretPinStatus().then(() => {
  //     this.setState({
  //       fetchingSecurePin: false
  //     })
  //     const { securePin } = this.props;
  //     if (!this.props.securePinError) {
  //       if (!securePin.securePinEnabled) {
  //         console.log("secure pin not enabled");
  //         if (actionType == "addManager") {
  //           return this.handleAddManagerAfterSecurePinPass()
  //         }
  //         if (actionType == "approval") {
  //           return this.handleApproveAccMgrReqAfterSecurePinValidation()
  //         }
  //       }
  //       if (!securePin.securePinVerified) {
  //         this.setState({
  //           fetchingSecurePin: true
  //         })
  //         console.log("secure pin not verified, go through secure pin flow");
  //         this.props.actions.getListOfUserNumbers().then(() => {
  //           this.setState({
  //             fetchingSecurePin: false
  //           })
  //           if (actionType === 'approval') {
  //             this.setState({
  //               approveManagerSecurePinModalStatus: true
  //             })
  //           } else if (actionType === 'addManager') {
  //             this.setState({
  //               addManagerSecurePinModalStatus: true
  //             })
  //           }
  //         });
  //       } else if (securePin.securePinVerified) {
  //         console.log("secure pin already verified");
  //         if (actionType == "addManager") {
  //           return this.handleAddManagerAfterSecurePinPass()
  //         }
  //         if (actionType == "approval") {
  //           return this.handleApproveAccMgrReqAfterSecurePinValidation()
  //         }
  //       }
  //     } else {
  //       this.setState({
  //         securePinError: true
  //       })
  //     }
  //   });
  // // };


  componentWillReceiveProps(nextProps) {
    const { memberPhoneNumber, memberEmailId } = nextProps
    if (this.props.memberEmailId !== nextProps.memberEmailId) {
      this.setState({
        phoneNumber: nextProps.memberPhoneNumber,
        emailId: nextProps.memberEmailId,
        showLearnMorePopUp: nextProps.showLearnMorePopUp
      })
    }
    if(this.props.managers.length < nextProps.managers.length) {
      this.setState({
        managersChanged: true
      })
    }
    if(this.state.managersChanged){
      // if (nextProps.event != this.props.event) {
        setTimeout(() => {
          this.setState({
            managersChanged: false
          })
        }, 3000);
    // }
    // if (this.props.approveManagerError || this.props.addManagerError) {
    //     this.props.actions.clearAccountManagerErrorCodes()
    //   }
    }
  }

  getAccountManagerRequestCard = (request) => {
    const { managers } = this.props
    const isMaxManagersReached = managers.length > MAXIMUM_ACCOUNT_MANAGERS_ACTIVE
    const userData = {
      "firstName": request.firstName,
      "lastName": request.lastName,
      "phoneNumber": request.phoneNumber,
      encryptedMdn: request.encryptedMdn,
      "emailId": request.emailId,
      "status": "APPROVED"
    }
    if (isMaxManagersReached == false) {
      return (
        <div key={request.phoneNumber + request.emailId}>
          <div className='row mt-1'>
            <p>Requested by {formatPhoneNumber(request.phoneNumber)} </p>
          </div>
          <div className='row'>
            <h4 tabIndex='0'>{request.firstName + '  ' + request.lastName}</h4>
            <p className="mb-0">{formatPhoneNumber(request.phoneNumber)}</p>
            <p className="mb-0">{request.emailId}</p>
          </div>
          <div className='row'>
            <div className='col-md-12 pl-0 ml-1 mt-1'>
              <button className='btn btn--round-invert btnsize' onClick={() => this.props.actions.postDenyManagerByAccountHolder(request)} analyticstrack="accountmanager-deny" >Deny</button>
              <button className='btn btn--round ml-1 btnsize' onClick={() => this.saveChangesClickedHandler("approveAccountManagerBlock", userData)} analyticstrack="accountmanager-approve">Approve</button>
            </div>
          </div>
          {this.props.denyManagerError.hasOwnProperty("data") && this.props.denyManagerError.payload.phoneNumber == request.phoneNumber ? 
            <p style={{ marginTop: "10px" }} className="errorDisplay">
              <span className="fa fa-exclamation-circle" />
                {getErrorMsgByCode(this.props.denyManagerError.data.statusCode)}
            </p> : ""}
          {this.props.approveManagerError && this.state.approveData.phoneNumber == request.phoneNumber ?
            <p style={{ marginTop: "10px" }} className="errorDisplay">
              <span className="fa fa-exclamation-circle" />
                {getErrorMsgByCode(this.props.approveManagerError)}
            </p> : ""}
          <div className='row seperator' />
        </div>
      )
    }
    return (
      <div>
        <div className='row mt-1'>
          <p>Requested by {formatPhoneNumber(request.phoneNumber)} </p>
        </div>
        <div className='row'>
          <h4 tabIndex='0'>{request.firstName + '  ' + request.lastName}</h4>
          <p className="mb-0">{formatPhoneNumber(request.phoneNumber)}</p>
          <p className="mb-0">{request.emailId}</p>
        </div>
        <div className='row'>
          <div className='col-md-12 pl-0 ml-1 mt-1'>
            <button className='btn btn--round-invert' onClick={(e) => this.handleDenyAccountManagerRequest(request)}>Deny</button>
            <button className='btn btn--round ml-1' disabled={isMaxManagersReached} onClick={(e) => { }}>Approve</button>
          </div>
        </div>
        <div className='row seperator' />
      </div>
    )
  }

  openTCModal = (e) => {
    e.preventDefault();
    this.setState({
      showTCPopUp: true
    })
  }

  handleClosePopup() {
    this.setState({
      showPopup: false
    })
  }

  handleRevokeAccess() {
    this.handleClosePopup()
    const { managerToRemove } = this.state
    // const postPayload = {
    //   "firstName": managerToRemove.firstName,
    //   "lastName": managerToRemove.lastName,
    //   "phoneNumber": managerToRemove.phoneNumber ? managerToRemove.phoneNumber === 'noLineAssigned' ? 'Not Applicable' : managerToRemove.encryptedPhoneNumber : 'Not Applicable',
    //   "emailId": managerToRemove.emailId,
    //   "acctTypeCode": managerToRemove.phoneNumber ? managerToRemove.phoneNumber === 'Not Applicable' ? 'FAC' : '' : 'FAC'
    // }
    this.props.actions.postRemoveManagerByAccountHolder(managerToRemove)
   // this.props.handleRemoveManager(this.state.managerToRemove)
  }

  onChangeInput = () => {
    // All  the validations goes here
    /*  const val = this.state.user;
      const useridInvalidMessages = JSON.parse(JSON.stringify(this.state.useridInvalidMessages));
      if(val.length === 0) {
        this.setState( { requiredError : true,  useridInvalidMessages: [
          { name: '6-60 characters', error: false, type: 'character'},
          { name: 'Not all numbers', error: false, type: 'number' },
          { name: 'Contains no spaces', error: false, type: 'space'}
        ] });
      } else {
        this.setState( { requiredError: false });
          if (val.indexOf(' ') !== -1) {
            let inavlidMessage =  useridInvalidMessages.find(message => message.type === 'space');
              inavlidMessage.error = true;
              this.setState({ useridInvalidMessages });
          } else {
              let inavlidMessage =  useridInvalidMessages.find(message => message.type === 'space');
              inavlidMessage.error = false;
              this.setState({ useridInvalidMessages });
          }
          if (val.match(/^([^0-9]*)$/)) {
              let inavlidMessage =  useridInvalidMessages.find(message => message.type === 'number');
              inavlidMessage.error = false;
              this.setState({ useridInvalidMessages });
          } else {
            let inavlidMessage =  useridInvalidMessages.find(message => message.type === 'number');
              inavlidMessage.error = true;
              this.setState({ useridInvalidMessages });
          }
      } */
  }

  handleOnChange = (inputType, inputValue) => {
    if (inputType == 'firstName' || inputType == 'lastName') {
      const validateName = /^[a-zA-Z]*$/// Avoid Special Characters and numbers as part of first name and last name
      if (validateName.test(inputValue)) {
        this.setState({ [inputType]: inputValue })
      }
    }
    else if (inputType == 'emailId') {
      // if (inputValue.split("@").length - 1 < 2) {
      //   this.setState({ [inputType]: inputValue })
      // }
if(inputValue.length>254)
return;
      if (inputValue.indexOf('..') >= 0||inputValue.indexOf(' ') >= 0)
        return
      // inputValue.replace(/[^a-zA-Z0-9_-@.]/g,'')
      const emails = inputValue.split("@");
      if (emails.length == 2 && emails[1].length > 63) {
        return;
      }
      if (emails.length - 1 < 2) {
        if (inputValue.split('.').length - 1 < 5)
          this.setState({ [inputType]: inputValue.replace(/[`~!#$%^&*()_|+\=÷¿?;:'",<>\{\}\[\]\\\/]/gi, '') })
      }
    }
    else {
      this.setState({ [inputType]: inputValue }, () => this.onChangeInput());
    }
  }

  getManagersView() {
    const { managers } = this.props
    if (accountManager) {
      return <ManagersListToAccountManager managers={managers} toggleLearnMorePopup={() => this.toggleLearnMorePopup()} />
    }
    return (
      <div>
        {
          managers.map((eachManager) => {
            if (eachManager.role === 'accountHolder') {
              return (
                <div key={eachManager.phoneNumber}>
                  <div className='row owner-info'>
                    <h4 className='manager-name'>{eachManager.firstName + ' ' + eachManager.lastName}( Account Owner )</h4>
                    <p>{formatPhoneNumber(eachManager.phoneNumber)}</p>
                    <p>{eachManager.emailId}</p>
                  </div>
                </div>
              )
            }
            return <ManagerCard managerInfo={eachManager} isNewlyAdded={this.props.addedManager.phoneNumber === eachManager.phoneNumber} />
          })
        }
      </div>
    )
  }

  showConfirmPopUp = (managerToRemove) => {
    this.props.actions.clearAccountManagerErrorCodes()
    this.setState({
      showPopup: true,
      managerToRemove
    })
  }

  getManagersEditView() {
    const { managers, revokedManager } = this.props
    if (accountManager) {
      return <ManagersListToAccountManager managers={managers} toggleLearnMorePopup={() => this.toggleLearnMorePopup()} />
    }
    return (
      <div>
        {
          managers.map((eachManager,i) => {
            const phoneNumber = eachManager.phoneNumber === 'Not Applicable' ? '' : formatPhoneNumber(eachManager.phoneNumber)
            if (eachManager.role === 'accountHolder') {
              return (
                <div key={eachManager.phoneNumber}>
                  <div className='row'>
                    <div className='row col-xs-12 col-sm-12 col-md-12'>
                      <h1>Current Account Managers</h1>
                    </div>
                    <div className='row col-xs-12 col-sm-1 col-md-1 hidden-xl-down'>
                    <a className='btn btn-anchor' onClick={() => this.props.handleEditCancel('cancelblock')} analyticstrack="accountmanager-cancel">Cancel</a>
                    </div>
                  </div>
                  <div className='row owner-info'>
                    <h4 className='manager-name mb-0'>{eachManager.firstName + ' ' + eachManager.lastName}( Account Owner )</h4>
                    <p className="mb-0">{phoneNumber}</p>
                    
                    <p className="mb-0">{eachManager.emailId}</p>
                  </div>
                  <div className='row seperator' />
                </div>
              )
            }
            return (
              <div>
                <div className='row owner-info-second' key={eachManager.phoneNumber}>
                  <div className='row col-xs-12 col-sm-11'>
                    <h4 className='manager-name'>{eachManager.firstName} {eachManager.lastName}</h4>
                    <p className="mb-0">{phoneNumber}</p>
                    <p className="mb-0">{eachManager.emailId}</p>
                  </div>
                  {
                    accountOwner &&
                    <div className='row col-xs-12 col-sm-1'>
                      <a className='btn btn-anchor' onClick={() => this.showConfirmPopUp(eachManager)} role='button' analyticstrack="accountmanager-remove">Remove</a>
                    </div>
                  }
                  
                </div>
                {this.state.managersChanged && i === this.props.managers.length - 1 ? <span className="col-xs-12 section-saved text-success"><i className="fa fa-check-circle"></i>
                Saved
              </span> : "" }
                {this.props.removeManagerError.hasOwnProperty("data")
                          && this.props.removeManagerError.payload.firstName === eachManager.firstName 
                          && this.props.removeManagerError.payload.lastName === eachManager.lastName
                          && this.props.removeManagerError.payload.phoneNumber === eachManager.phoneNumber ? 
                            <p style={{textAlign: "right"}} >
                              <span className="fa fa-exclamation-circle"/>
                              {getErrorMsgByCode(
                                  this.props.removeManagerError.data.errorCode || 
                                  this.props.removeManagerError.data.statusCode)}
                            </p>
                          : "" }
                <div className='row seperator' />
              </div>
            )
          })
        }
        {
          revokedManager.firstName && this.props.managers.length <= 3 &&
          <div className='row owner-info-second'>
              {this.props.undoRemoveManagerError.hasOwnProperty("data")
                && this.props.undoRemoveManagerError.payload.firstName === revokedManager.firstName 
                && this.props.undoRemoveManagerError.payload.lastName === revokedManager.lastName
                && this.props.undoRemoveManagerError.payload.phoneNumber === revokedManager.phoneNumber ? 
                  <p>
                    <span className="fa fa-exclamation-circle"/>
                    {getErrorMsgByCode(
                        this.props.undoRemoveManagerError.data.errorCode || 
                        this.props.undoRemoveManagerError.data.statusCode)}
                  </p>
                : "" }
            <div className='row col-xs-11 col-sm-11 undo-message-cont'>
              <span className='text-success'>
              <i className="fa fa-check-circle"></i>
              </span>
              <p className='undo-message'>Account Manager {revokedManager.firstName + ' ' + revokedManager.lastName} removed.</p>
            </div>
            <div className='row col-xs-1 col-sm-1'>
              <a className='undo' role='button' onClick={() => this.props.actions.undopostAddManagerByAccountHolder(this.props.revokedManager)} analyticstrack="accountmanager-undo">Undo</a>
            </div>
          </div>
         }
      </div>
    )
  }

  handleEditNewMemberEmail() {
    this.setState({
      isEditEmailOnAccountMemberSelected: true
    })
  }

  handleSaveNewMemberEmail() {
    this.setState({
      isEditEmailOnAccountMemberSelected: false
    })
  }

  handleDenyAccountManagerRequest(newRequest) {
    //const encryptedPhoneNumber = this.props.accountManagerRequests.find(mtnObj => mtnObj.phoneNumber == newRequest.phoneNumber).encryptedPhoneNumber;
    const payload = {
      "role": '',
      "firstName": newRequest.firstName,
      "lastName": newRequest.lastName,
      "phoneNumber": newRequest.phoneNumber,
      "encryptedPhoneNumber":newRequest.encryptedPhoneNumber,
      "emailId": newRequest.emailId,
      "status": "DENIED"
    }
    this.props.actions.postDenyManagerByAccountHolder(payload)
    this.props.handleDenyAccountManagerRequest(newRequest)
  }

  // handleApproveAccountManagerClick = () => {
  //   this.setState({
  //     approveAccountManager: true
  //   })
  //   // this.handleAppproveAccountManagerRequest()
  // }

  handleAppproveAccountManagerRequest(newRequest) {
    const encryptedPhoneNumber = this.props.accountManagerRequests.find(mtnObj => mtnObj.phoneNumber == newRequest.phoneNumber).encryptedPhoneNumber;
    const approvedRequest = {
      "firstName": newRequest.firstName,
      "lastName": newRequest.lastName,
      "phoneNumber": newRequest.phoneNumber,      
      "encryptedMdn": encryptedPhoneNumber,         
      "emailId": newRequest.emailId,
      "status": "APPROVED"
    }
    this.setState({
      approvedRequest
    })
  }

  handleUndoDenyAccountManagerRequest(deniedAccountManager) {
    const sendRequestPayload = {
      status: 'PENDING',
      firstName: deniedAccountManager.firstName,
      lastName: deniedAccountManager.lastName,
      phoneNumber: deniedAccountManager.encryptedPhoneNumber,
      emailId: deniedAccountManager.emailId
    }
    this.props.actions.postSendRequestForAccountManager(sendRequestPayload)
    this.props.handleUndoDenyAccountManagerRequest()
  }

  handleSendRequestForAccountManager(newRequest,e) {
    e.preventDefault();
    const payload = {
      "role": '',
      "firstName": this.state.firstName,
      "lastName": this.state.lastName,
      "phoneNumber": this.state.encryptedPhoneNumber || this.props.encryptedPhoneMem,
      "emailId": this.state.emailId,
      "status": "PENDING"
    }
    this.props.actions.postSendRequestForAccountManager(payload)
    this.props.handleSendRequestForAccountManager(newRequest)
  }

  getAccountManagerRequestsView() {
    const { accountManagerRequests, deniedAccountManagerRequests, managers, amgrCount } = this.props
    if (accountMember) return <div className='row request-header'>
      <h1>[{amgrCount}] Account Managers exist (max of 3) </h1>
    </div> // Account Members do not see pending requests
    const isMaxManagersReached = managers.length > MAXIMUM_ACCOUNT_MANAGERS_ACTIVE
    if (accountManagerRequests.length > 0 || deniedAccountManagerRequests.length > 0) {
      return (
        <div>
          <div className='row request-header'>
            <h1> Account Manager Requests </h1>
          </div>
          {
            isMaxManagersReached && <p style={{'margin-left':'-15px'}} className="mt-1 mb-0">You can have a maximum of three Account Managers at a time. To add a new Account Manager, you'll have to remove one first.</p>

          }
          {
            accountManagerRequests.map(eachRequest => {
            if(eachRequest !== null){
              return (
                <div key={eachRequest.phoneNumber}>
                  {this.getAccountManagerRequestCard(eachRequest)}
                </div>
              )
            }
              
            })
          }
          {
            deniedAccountManagerRequests ? deniedAccountManagerRequests.map(manager => 
              (
                <div className='row owner-info-second'>
                  {this.props.sendAccountManagerRequestError ? 
                    <p className="errorDisplay">
                      <span className="fa fa-exclamation-circle"/>
                      {getErrorMsgByCode(this.props.sendAccountManagerRequestError)}
                    </p> : 
                    "" }
                <div className='row col-xs-12 col-sm-11 undo-message-cont'>
                  <span className='text-success'><i className='fa fa-check-circle'></i></span>
                  <p className='undo-message'>Account Manager Request from {formatPhoneNumber(manager.phoneNumber)} is denied </p>
                </div>
                <div className='row col-xs-12 col-sm-1'>
                  <a className='undo' role='button' onClick={() => this.props.actions.postSendRequestForAccountManagerOnUndo({
                    ...manager,
                    phoneNumber: manager.encryptedPhoneNumber,
                    status:'PENDING'
                  })} analyticstrack="accountmanager-undo">Undo</a>
                </div>
              </div>
              )
            ) : ""
          }
        </div>
      )
    }

    return <div />
  }

  handleAddManagerAfterSecurePinPass = (e) => {
    const addManagerPayload = {
      "firstName": this.state.firstName,
      "lastName": this.state.lastName,
      "phoneNumber": this.state.phoneNumber === 'noLineAssigned' ? 'Not Applicable' : this.state.phoneNumber.split(".").join(""),
      "emailId": this.state.emailId,
      "acctTypeCode": this.state.phoneNumber === 'noLineAssigned' ? 'FAC' : ''
    }
    if(this.state.phoneNumber !== 'noLineAssigned'){
      const encryptedPhoneNumber = this.props.mtns.find(mtnObj => mtnObj.mdn == this.state.phoneNumber.split(".").join("")).encryptedMdn
      addManagerPayload.encryptedMdn = encryptedPhoneNumber
    }
    this.props.handleSave('accountmanagerBlock', this.state, e)
    this.props.actions.postAddManagerByAccountHolder(addManagerPayload)
    // this.setState(this.getinitialState())
    this.setState({
      firstName: '',
      lastName: '',
      phoneNumber: this.props.memberPhoneNumber,
      emailId: this.props.memberEmailId
    })
  }

  handleAddManager = (e) => {
    this.setState({
      showTCPopUp: true
    })
    //this.startSecurePin(e, {}, 'addManager')
    }

  getManagerAddView(managers, firstName, lastName, phoneNumber, emailId) {
    if (accountManager) return <div />
    const { newAccountMemberRequest, mtns } = this.props
    if (newAccountMemberRequest.status === 'not requested') {
      if (accountOwner && managers.length <= MAXIMUM_ACCOUNT_MANAGERS_ACTIVE) {
        return (
          <div className='row add-manager-cont'>
            {this.state.moveCancelButton === 1 && !this.props.showManagerEdit && this.props.managerEditMode ? <a className='btn btn-anchor' style={{ float: 'right' }} onClick={() => this.props.handleEditCancel('cancelblock')} analyticstrack="accountmanager-cancel">Cancel</a> : ""}
            <h4 tabIndex='0'>Add Account Managers</h4>
            <a className='question' onClick={() => { this.props.actions.showLearnMorePopUp() }} analyticstrack="accountmanager-accessroles"> What can an Account Manager do ?</a>
            <p className='answer'>
              An Account Manager does NOT have to have a mobile number on your
              account. By providing a name only, they will be able to manage all lines
               on the account in retails stores and by calling Customer Service.
            </p>
            <div>
              <form autoComplete="off" onSubmit={this.openTCModal}>
              <div>
                <div>
                  <div className='add-manager-fields'>
                    <div className='manager-fn-cont '>
                      <label htmlFor='userId'>First Name</label>
                      <InputField type='text'  autoComplete='off' handleOnChange={(e) => { this.handleOnChange('firstName', e.target.value) }} placeholder='Name' name='firstName' value={firstName} />
                    </div>
                    <div className='manager-ln-cont '>
                      <label htmlFor='userId'>Last Name</label>
                      <InputField type='text'  autoComplete='off' handleOnChange={(e) => { this.handleOnChange('lastName', e.target.value) }} placeholder='Name' name='lastName' value={lastName} />
                    </div>
                  </div>
                </div>
                <div>
                  <p>If you assign a mobile number and email address, the Account
                           Manager will be given My Verizon Online access to your account.</p>
                </div>
                <div className='contact-cont'>
                  <div>
                    <h4>Mobile Number</h4>
                    <select value={this.state.phoneNumber} onChange={(e) => this.handleOnChange('phoneNumber', e.target.value)}>
                      <option value='' >Select</option>
                      <option value='noLineAssigned' >No Line Assigned</option>
                      {
                        mtns.map(eachMtns => {
                          return <option value={formatPhoneNumber(eachMtns.mdn)}>{formatPhoneNumber(eachMtns.mdn)}</option>
                        })
                      }
                    </select>
                  </div>
                  {
                    this.state.phoneNumber != 'noLineAssigned' &&
                    <div>
                      <h4>Email Address</h4>
                      <InputField type='text'  autoComplete='off' handleOnChange={(e) => { this.handleOnChange('emailId', e.target.value) }} placeholder='name@domain.com' name='email' value={emailId} />
                    </div>
                  }
                </div>
                <div style={{paddingLeft: "0"}} className='footer col-xs-12'>
                {this.props.addManagerError ? <p style={{width: "50%", marginLeft: "0", marginRight: "auto"}} className="errorDisplay"><span className="fa fa-exclamation-circle"></span> {getErrorMsgByCode(this.props.addManagerError)}</p> : ""}
                  <a className='btn btn--round-invert' role='button' onClick={() => this.props.handleEditCancel('cancelblock')} analyticstrack="accountmanager-cancel">Cancel</a>
                  <button className='btn btn--round' type="submit" disabled={reactGlobals.isCsr || !(this.state.firstName && this.state.lastName && this.state.phoneNumber)} onClick = {this.openTCModal} analyticstrack="accountmanager-add">Add Manager</button>
                </div>
              </div>
              </form>
            </div>
          </div>
        )
      }
      if (accountMember) {
        return (
          <div className='row add-manager-cont'>
            <h4 tabIndex='0'>Request Account Manager Access</h4>
            <a className='question' onClick={() => { this.props.actions.showLearnMorePopUp() }} analyticstrack="accountmanager-accessroles"> What can an Account Manager do ?</a>
            <p className='answer'>
              Want to become an Account Manager? Submit a request to your Account Owner by filling out the information below. You must be 18 years or older to be an Account Manager.
              </p>
            <div>
              <form autoComplete="off" onSubmit={(e) => this.handleSendRequestForAccountManager(this.state,e)}>
              <div>
                <div>
                  <div className='add-manager-fields'>
                    <div className='manager-fn-cont '>
                      <label htmlFor='userId'>First Name</label>
                      <InputField type='text'  autoComplete='off' handleOnChange={(e) => { this.handleOnChange('firstName', e.target.value) }} placeholder='Name' name='firstName' value={firstName} />
                    </div>
                    <div className='manager-ln-cont '>
                      <label htmlFor='userId'>Last Name</label>
                      <InputField type='text'  autoComplete='off' handleOnChange={(e) => { this.handleOnChange('lastName', e.target.value) }} placeholder='Name' name='lastName' value={lastName} />
                    </div>
                  </div>
                </div>
                <div className='contact-cont'>
                  <div className='row'>
                    <div className='col-sm-4'>
                      <label>Phone Number</label>
                    </div>
                    <div className='p-t-7 col-sm-8'>
                      <p>{formatPhoneNumber(phoneNumber)}</p>
                    </div>
                  </div>
                  <div className='row'>
                    <div className='col-sm-4'>
                      <label>Email Address</label>
                    </div>
                    <div className='p-t-7 col-sm-5'>
                      {
                        <p>{emailId}</p>
                      }
                    </div>


                  </div>
                </div>
                <div className='footer col-xs-12'>
                  <a className='btn btn--round-invert' role='button' onClick={() => this.props.handleEditCancel('cancelblock')} analyticstrack="accountmember-cancel">Cancel</a>
                  <button className='btn btn--round ml-1' type="submit" disabled={!(this.state.firstName && this.state.lastName)} onClick={() => this.handleSendRequestForAccountManager(this.state)} analyticstrack="accountmember-send">Send Request</button>
                </div>
              </div>
              </form>
            </div>
          </div>
        )
      }
    }

    if (this.props.newAccountMemberRequest.status === 'request pending') {

      return (
        <div className='row'>
          <h2 className='account-manager-request-heading'>Request to Become an Account Manager</h2>
          <p className='account-member-'>
            Want to become an Account Manager? Submit a request to your Account Owner by filling out the information below. You must be 18 years or older to be an Account Manager.
                  <br />
            <br />
            <br />
            Your request to become an Account Manager is now with the Account Owner for approval. If accepted, you’ll get an email with next steps.
            </p>
          <h4 className='account-manager-request-pending'>
          You currently have [1] pending request(s). Want an update? Reach out to your Account Owner.
            </h4>
        </div>
      )
    }
    if (this.props.newAccountMemberRequest.status === 'request denied') {
      return (
        <div className='row'>
          <h2 className='account-manager-request-heading'>Request to Become an Account Manager</h2>
          <h3>
            Your Account Owner  has denied your request
              </h3>
              <br/>
          <p className='account-member-'>
          You can always submit another request 45 days after your intial request. Want Account Manager access sooner? Reach out to your Account Owner.
           They can add you as an Account Manager manually through their profile page in Verizon.
            </p>
        </div>
      )
    }

    if (accountOwner) {
      return (
        <div className='row add-manager-cont'>
          <h4 tabIndex='0'>Add Account Managers</h4>
          <a className='question' onClick={() => { this.props.actions.showLearnMorePopUp() }} analyticstrack="accountmanager-accessroles"> What can an Account Manager do ?</a>
          <div className='warning'>
            <p>You can have a maximum of<strong> three additional Account Managers </strong>at a time. To add a new Account Manager, you'll have to remove one first.</p>
          </div>
        </div>
      )
    }
    return (
      <div className='row add-manager-cont'>
        <h4 tabIndex='0'>Request to Become an Account Manager</h4>
        <a className='question' onClick={() => { this.props.actions.showLearnMorePopUp() }} analyticstrack="accountmanager-accessroles"> What can an Account Manager do ?</a>
        <p className='answer'>
          Want to become an Account Manager? Submit a request to your Account Owner by filling out the information below. You must be 18 years or older to be an Account Manager.
          </p>
        <div>
          {
            managers.length < 4 ?
              <div>
                <div>
                  <div className='add-manager-fields'>
                    <div className='manager-fn-cont '>
                      <label htmlFor='userId'>First Name</label>
                      <InputField type='text' autoComplete='off' handleOnChange={(e) => { this.handleOnChange('firstName', e.target.value) }} placeholder='Name'
                        analyticstrack="accountmanager-add-fname" name='firstName' value={firstName} />
                    </div>
                    <div className='manager-ln-cont '>
                      <label htmlFor='userId'>Last Name</label>
                      <InputField type='text' autoComplete='off' handleOnChange={(e) => { this.handleOnChange('lastName', e.target.value) }} placeholder='Name'
                        analyticstrack="accountmanager-add-lname" name='lastName' value={lastName} />
                    </div>
                  </div>
                </div>
                <div className='row'>
                  <div className='col-sm-3'>
                    <label>Phone Number</label>
                  </div>
                  <div className='p-t-7 col-sm-3'>
                    <p>989.235.3666</p>
                  </div>
                </div>
                <div className='row'>
                  <div className='col-sm-3'>
                    <label>Email Address</label>
                  </div>
                  <div className='p-t-7 col-sm-3'>
                    {
                      this.state.isEditEmailOnAccountMemberSelected ?
                        <InputField type='text'  autoComplete='off' handleOnChange={(e) => { this.handleOnChange('emailId', e.target.value) }}
                          analyticstrack="accountmanager-emailid" placeholder='name@domain.com' name='email' value={emailId} /> :
                        <p>samurai.jack@verizon.com</p>
                    }
                  </div>
                  <div className='col-sm-1'>
                    {
                      this.state.isEditEmailOnAccountMemberSelected ?
                        <a className='edit-btn' onClick={() => this.handleSaveNewMemberEmail()} analyticstrack="accountmanager-save">Save</a> :
                        <a className='edit-btn' onClick={() => this.handleEditNewMemberEmail()} analyticstrack="accountmanager-edit">Edit</a>
                    }
                  </div>
                  <div className='footer col-xs-12'>
                    <a className='btn' role='button' onClick={() => this.props.handleEditCancel('cancelblock')} analyticstrack="accountmember-cancel">Cancel</a>
                    <button className='btn btn--round ml-1' onClick={(e) => { this.handleSendRequestForAccountManager(this.state) }} analyticstrack="accountmember-save">Send Request</button>
                  </div>
                </div>
              </div> :
              <div className='warning'>
                <p>You can have a maximum of <strong>three additional Account Managers</strong> at a time. To add a new Account Manager, you’ll have to remove one first</p>
              </div>
          }
        </div>
      </div>
    )
  }
 
  toggleTCPopUp(){
    this.setState({
      showTCPopUp : !this.state.showTCPopUp
    })
  }

  onAcceptOfTC(e){
    this.toggleTCPopUp()
    this.saveChangesClickedHandler('accountmanagerBlock', {
                    "firstName": this.state.firstName,
                    "lastName": this.state.lastName,
                    "phoneNumber": this.state.phoneNumber === 'noLineAssigned' ? 'Not Applicable' : this.state.phoneNumber.split(".").join(""),
                    "emailId": this.state.emailId,
                    "acctTypeCode": this.state.phoneNumber === 'noLineAssigned' ? 'FAC' : ''
            })
            this.setState({
              firstName: '',
              lastName: '',
              phoneNumber: this.props.memberPhoneNumber,
              emailId: this.props.memberEmailId
            })
    //this.startSecurePin(e, {}, 'addManager')
  }

  handleEditCancel = () => {
    this.props.handleEditCancel('accountmanagerblock')
    this.props.actions.fetchMtns()
    this.props.actions.fetchManagerRequests()
  }

  toggleLearnMorePopup = () => {

    if (this.props.showLearnMorePopUp) {
      this.props.actions.hideLearnMorePopUp()
    } else {
      this.props.actions.showLearnMorePopUp()
    }
  }
  componentDidMount() {
    this.handleResize()
    window.addEventListener('resize', this.handleResize)
  }

  closeModal = () => {
    // this.props.actions.clearErrorCodes()
    this.setState({
      errorModal: false,
      securePinError: false,
      addManagerSecurePinModalStatus: false,
      approveManagerSecurePinModalStatus: false,
      removeManagerSecurePin: false
    });
  };

  handleResize = () => {
    if (window.innerWidth < 990 && window.innerWidth > 715) {
      this.setState({
        moveCancelButton: 1
      })
    } else if (window.innerWidth < 715) {
      this.setState({
        moveCancelButton: 2
      })
    }
    else {
      this.setState({
        moveCancelButton: 0
      })
    }
  }

  handleApproveAccMgrReqAfterSecurePinValidation() {
    const { approvedRequest } = this.state
    this.props.actions.postApproveManagerByAccountHolder(approvedRequest)
    this.handleAppproveAccountManagerRequest(approvedRequest)
  }
  render() {
    // let kvarray = this.props.mtns
    // console.log(kvarray)
    // let encryptmdn = kvarray.map(obj => 
    //   obj.encryptedMdn
    // )

    const { firstName, lastName, phoneNumber, emailId } = this.state;
    const { transferOfServiceEditMode, preferenceCenterEditMode, documentsReceiptsEditMode, greetingEditMode, showManagerEdit, managerEditMode, managers, showRequestSuccessPopup } = this.props;
    const editableClassName = managerEditMode ? 'description_box--edit-view' : 'description_box_disabled';
    const popStyle = {
      'top': '15%',
      'max-height': '70%'
    };
    const revokepopUpStyle = {
      'top': '30%',
      'max-height': '70%'
    };
    return (
      <div className={`row description_box ${editableClassName}`}>
        <Popup popStyle={revokepopUpStyle} hideX={true} showPopup={this.state.showPopup} onClosePopup={() => { this.handleClosePopup() }} >
          <RevokeAccess showSpinner={this.props.removeManagerSpinner} fetchingSecurePin={this.state.fetchingSecurePin} handleRevokeAccess={this.saveChangesClickedHandler} onClosePopup={() => { this.handleClosePopup() }} />
        </Popup>
        <Popup popStyle={revokepopUpStyle} showPopup={this.props.showRequestSuccessPopup}>
          <RequestSent onClosePopup={() => { this.props.toggleRequestSuccessPopup() }} />
        </Popup>
        <Popup popStyle={popStyle} showPopup={this.props.showLearnMorePopUp}>
          <AccessRoles onClosePopup={() => { this.toggleLearnMorePopup() }} />
        </Popup>
        <Popup popStyle={popStyle} showPopup={this.state.showTCPopUp}>
          <TermsAndConditions onClosePopup={() => { this.toggleTCPopUp() }} onContinue={(e)=>{this.onAcceptOfTC(e)}} newManagerDetails={this.getNewManagerDetails()}/>
        </Popup>
        <div className='clearfix'></div>
        <div className='body'>
          <div className='col-xs-12 col-sm-4 description_box__header' style={{ padding: "0" }} >
            <div className='col-xs-12' style={{ padding: "0" }}>
              {this.state.moveCancelButton === 2 && !showManagerEdit && managerEditMode ? <a className='btn btn-anchor' style={{ float: 'right' }} onClick={() => this.props.handleEditCancel('cancelblock')} analyticstrack="accountmanager-cancel">Cancel</a> : ""}

              <h4 tabIndex='0' >Account managers</h4>
              {/*
                  showManagerEdit && ( accountOwner || accountMember ) &&
                  <div className='description_box__edit description_box__edit_section col-xs-4'>
                    <a className='btn btn-anchor'  onClick={() => this.handleEditCancel()} role='button'>Edit</a>
                  </div> */
              }
            </div>
            <p>Assign account managers to let others access and make changes to all information and lines on your account.</p>
          </div>
          <div className='col-xs-12 col-sm-8 description_box__large-container'>
            {
              (showManagerEdit || greetingEditMode || transferOfServiceEditMode || documentsReceiptsEditMode || preferenceCenterEditMode) && this.getManagersView()
            }
            {
              !showManagerEdit && managerEditMode &&
              <div>
                {this.getManagersEditView()}
                {this.getAccountManagerRequestsView()}
                {this.getManagerAddView(managers, firstName, lastName, this.props.memberPhoneNumber, emailId === undefined ? this.props.memberEmailId : emailId)}
              </div>
            }
            {
              showManagerEdit && (accountOwner || accountMember) &&
              <div className='description_box__edit description_box__edit_section top-0'>
                <a className='btn btn-anchor' onClick={() => this.handleEditCancel()} role='button' analyticstrack="accountmanager-edit" >Edit</a>
              </div>
            }
          </div>
        </div>

        <Modal
          modalStatus={this.state.addManagerSecurePinModalStatus}
          closeModal={this.closeModal}
          tagId={this.props.tagId}
        >
          <SecurePin
            handleSaveType="accountmanagerBlock"
            closeModal={this.closeModal}
            userVerified={this.props.userVerified}    
            updateTagId={() => this.props.actions.updateTagId("acctmanagers-confirmsecurepin")}            
            handleSave={() => this.props.actions.postAddManagerByAccountHolder(this.state.approveData)}
          />
        </Modal>
        <Modal
          modalStatus={this.state.errorModal}
          closeModal={this.closeModal}
          tagId="addmanager-error"
        >
          <div>{getErrorMsgByCode(this.props.error)}</div>
        </Modal>
        <Modal
          modalStatus={this.state.approveManagerSecurePinModalStatus}
          closeModal={this.closeModal}
          tagId={this.props.tagId}
        >
          <SecurePin
            handleSaveType="approveAccountManagerBlock"
            closeModal={this.closeModal}
            userVerified={this.props.userVerified}
            updateTagId={() => this.props.actions.updateTagId("acctmanagersapprove-confirmsecurepin")}            
            handleSave={() => this.props.actions.postApproveManagerByAccountHolder(this.state.approveData)}
          />
        </Modal>
        <Modal
          modalStatus={this.state.removeManagerSecurePin}
          closeModal={this.closeModal}
          tagId={this.props.tagId}
        >
          <SecurePin
            handleSaveType="removeAccountManager"
            closeModal={this.closeModal}
            userVerified={this.props.userVerified}
            updateTagId={() => this.props.actions.updateTagId("acctmanagersremove-confirmsecurepin")}            
            handleSave={() => this.props.actions.postRemoveManagerByAccountHolder(this.state.managerToRemove)}
          />
        </Modal>
        {this.state.fetchingSecurePin || this.props.showSpinner ? <Spinner /> : ""}

      </div>
    )
  }
}

const mapStateToProps = state => {
  return {
    mtns: state.accManagerReducer.mtns,
    accountManagerRequests: state.accManagerReducer.accountManagerRequests,
    memberEmailId: state.accManagerReducer.emailId,
    memberPhoneNumber: state.accManagerReducer.phoneNumber,
    encryptedPhoneMem: state.accManagerReducer.encryptedPhoneNumber,
    showLearnMorePopUp: state.accManagerReducer.showLearnMorePopUp,
    securePin: state.security.secretPin,
    isSecurePinValidated: state.security.isSecurePinValidated,
    addManagerError: state.accManagerReducer.addManagerError,
    approveManagerError: state.accManagerReducer.approveManagerError,
    securePinError: state.security.securePinError,
    userVerified: state.accManagerReducer.userVerified,
    amgrCount: state.accManagerReducer.amgrCount,
    revokedManager: state.accManagerReducer.revokedManager,
    removeManagerError: state.accManagerReducer.removeManagerError,
    undoRemoveManagerError: state.accManagerReducer.undoRemoveManagerError,
    deniedAccountManagerRequests: state.accManagerReducer.deniedAccountManagerRequests,
    sendAccountManagerRequestError: state.accManagerReducer.sendAccountManagerRequestError,
    denyManagerError: state.accManagerReducer.denyManagerError,
    managers: state.accManagerReducer.managers,
    showSpinner: state.accManagerReducer.showSpinner,
    removeManagerSpinner: state.accManagerReducer.removeManagerSpinner,
    tagId: state.security.tagId
  }
}

const mapDispatchToProps = dispatch => ({
  actions: bindActionCreators(actions, dispatch),
})

export default connect(mapStateToProps, mapDispatchToProps)(AccountManagerBlock)