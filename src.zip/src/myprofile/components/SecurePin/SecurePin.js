import React, { Component } from "react";
import { connect } from "react-redux";
import {
  sendSecurePinToPhone,
  getSecretPinStatus,
  getListOfUserNumbers,
  confirmSecurePinCode
} from "../Security/actions/fetchSecurities";
import { getErrorMsgByCode } from "../../../utils/config";
import Spinner from "../Spinner/Spinner";
import ListOfAccountNumbersModal from "./components/ListOfAccountNumbersModal";
import AuthorizationCodeModal from "./components/AuthorizationCodeModal";

class SecurePin extends Component {
  state = {
    selectedPhone: null,
    listOfAccountNumbersModal: false,
    authorizationCodeModal: false,
    authorizationCode: "",
    finalAuthorizationModal: false,
    afterGetRequest: [],
    fetchingSecurePin: false
    // authCodeExpired: false
  };

  componentDidUpdate(prevProps) {
    if (prevProps.listOfUserNumbers !== this.props.listOfUserNumbers) {
      if (
        this.props.handleSaveType == "enhancedAuth" &&
        this.props.enhancedAuthData
      ) {
        const accountOwnerNumber = this.props.listOfUserNumbers.filter(
          userNumbers => userNumbers.mtn == this.props.enhancedAuthData.mdn
        );
        this.setState({
          afterGetRequest: accountOwnerNumber,
          listOfAccountNumbersModal: true,
          authorizationCodeModal: false,
          authorizationCode: "",
          selectedPhone: null
          // authCodeExpired: false
        });
      } else {
        this.setState({
          afterGetRequest: this.props.listOfUserNumbers,
          listOfAccountNumbersModal: true,
          authorizationCode: "",
          selectedPhone: null,
          authorizationCodeModal: false
          // authCodeExpired: false
        });
      }
    }
    // if (this.props.handleSaveType == "accountmanagerBlock") {
    //   if (
    //     this.props.addManagerError != prevProps.addManagerError ||
    //     this.props.addedManager != prevProps.addedManager
    //   ) {
    //     this.setState({
    //       authorizationCodeModal: false,
    //       listOfAccountNumbersModal: false,
    //       finalAuthorizationModal: true,
    //       authorizationCode: ""
    //     });
    //   }
    // }
    // if (this.props.handleSaveType == "approveAccountManagerBlock") {
    //   if (
    //     this.props.approveManagerError != prevProps.approveManagerError ||
    //     this.props.managers.length != prevProps.managers.length
    //   ) {
    //     this.setState({
    //       authorizationCodeModal: false,
    //       listOfAccountNumbersModal: false,
    //       finalAuthorizationModal: true,
    //       authorizationCode: ""
    //     });
    //   }
    // }
  }

  sendCodeToPhoneHandler = () => {
    this.setState({
      fetchingSecurePin: true
    });
    this.props
      .sendSecurePinToPhone(
        this.state.selectedPhone.encryptedSecurePinMtn,
        reactGlobals.accountNumber
      )
      .then(() => {
        this.setState({
          fetchingSecurePin: false
        });
        if (!this.props.sendSecurePinError) {
          // setTimeout(() => {
          //   this.setState({
          //   authCodeExpired: true
          //   })
          // }, 60000);
          this.setState({
            listOfAccountNumbersModal: false,
            authorizationCodeModal: true
          });
        }
      });
  };

  authorizationCodeConformation = event => {
    event.persist();
    this.setState({
      fetchingSecurePin: true
    });
    this.props
      .confirmSecurePinCode(
        this.state.selectedPhone.encryptedSecurePinMtn,
        reactGlobals.accountNumber,
        this.state.authorizationCode
      )
      .then(() => {
        this.setState({
          fetchingSecurePin: false
        });
        if (!this.props.confirmSecurePinError) {
          if (this.props.isSecurePinValidated) {
            const { handleSaveType } = this.props;
            // if (
            //   handleSaveType === "enhancedAuth" ||
            //   handleSaveType === "emailBlock" ||
            //   handleSaveType === "billingAddressBlock" ||
            //   handleSaveType === "serviceAddressBlock" || 
            //   handleSaveType === "primaryPhoneBlock" || 
            //   handleSaveType === "questionForm"
            // ) {
              this.props.handleSave().then(() => {
                if(this.props.userVerified === false){
                  const afterGetRequest = this.state.afterGetRequest.map(item => Object.assign({}, item, { picked: false }))
                  return this.setState({
                    listOfAccountNumbersModal: true,
                    authorizationCodeModal: false,
                    authorizationCode: "",
                    selectedPhone: null,
                    afterGetRequest
                  })
                } else {
                  if(handleSaveType === "primaryPhoneBlock"){
                    if(!this.props.primaryPhoneFailure){
                      this.props.closeModal()      
                      this.props.handleEditCancel()                      
                    } else {
                      this.props.closeModal()      
                    }
                  } else if (handleSaveType === "approveAccountManagerBlock" || handleSaveType === "accountmanagerBlock") {
                    if(this.props.approveManagerError || this.props.addManagerError){
                      this.props.closeModal()
                    } else {
                      this.setState({
                        finalAuthorizationModal: true,
                        authorizationCodeModal: false
                      })
                    }
                  } else {
                    this.props.closeModal()
                  }
                }
              })
            // }
            // if (
            //   handleSaveType === "approveAccountManagerBlock" ||
            //   handleSaveType === "accountmanagerBlock"
            // ) {
            //   return this.props.handleSave();
            // }
            // console.log("got this far")
            // this.props.handleSave(
            //   this.props.handleSaveType,
            //   this.props.handleSaveData,
            //   event
            // ).then(() => console.log("Waiting"))
            // return this.props.closeModal();
          }
        } else {
          this.setState({
            authorizationCode: ""
          });
        }
      });
  };

  handleAuthCodeChange = event => {
    const { name, value } = event.target;
    const re = /^[0-9\b]+$/;
    if (value == "" || re.test(value)) {
      if (value.length <= 6) {
        this.setState({
          [name]: value
        });
      }
    }
  };

  handleRadioInputChange = event => {
    const afterGetRequest = this.state.afterGetRequest.map(el => {
      if (el.mtn == event.target.getAttribute("id")) {
        this.setState({ selectedPhone: el });
        return Object.assign({}, el, { picked: true });
      } else {
        return Object.assign({}, el, { picked: false });
      }
    });
    this.setState({ afterGetRequest });
  };

  renderModalContent() {
    // if (!this.props.error) {
    // if(this.state.authCodeExpired){
    //   return <p>The authorization code that we sent to your device has expired.</p>
    // }
    if (this.props.confirmSecurePinAttempts >= 3) {
      return <div>You have entered the incorrect code too many times.</div>;
    }
    if (this.props.getListOfUserNumbersError) {
      return (
        <div>
          <p>{this.props.getListOfUserNumbersError}</p>
          <button
            className="btn btn--round-invert"
            onClick={this.props.closeModal}
          >
            Close
          </button>
        </div>
      );
    }
    if (this.state.listOfAccountNumbersModal) {
      return (
        <ListOfAccountNumbersModal
          fetchingSecurePin={this.state.fetchingSecurePin}
          afterGetRequest={this.state.afterGetRequest}
          handleRadioInputChange={this.handleRadioInputChange}
          selectedPhone={this.state.selectedPhone}
          sendCodeToPhoneHandler={this.sendCodeToPhoneHandler}
          closeModal={this.props.closeModal}
          sendSecurePinError={this.props.sendSecurePinError}
        />
      );
    } else if (this.state.authorizationCodeModal) {
      return (
        <AuthorizationCodeModal
          fetchingSecurePin={this.state.fetchingSecurePin}
          authorizationCode={this.state.authorizationCode}
          handleAuthCodeChange={this.handleAuthCodeChange}
          confirmSecurePinError={this.props.confirmSecurePinError}
          showSpinner={this.props.showSpinner}
          authorizationCodeConformation={this.authorizationCodeConformation}
          closeModal={this.props.closeModal}
          fetchingManageAccount={this.props.fetchingManageAccount}
        />
      );
    } else if (this.state.finalAuthorizationModal) {
        if (this.props.addManagerError || this.props.approveManagerError) {
          return (
            <div>
              <p>
                {getErrorMsgByCode(
                  this.props.addManagerError || this.props.approveManagerError
                )}
              </p>
              <button
                className="btn btn--round-invert"
                onClick={this.props.closeModal}
              >
                Close
              </button>
            </div>
          );
        }
        return (
          <div>
            <h1>Your Account Managers have been updated.</h1>
            <p>Account Manager(s) added.</p>
            <div>
              <p>
                {this.props.selectedPhone
                  ? this.props.listOfUserNumbers.find(
                      item =>
                        item.encryptedSecurePinMtn === this.props.selectedPhone
                    ).formattedMtn
                  : ""}
              </p>
            </div>
            <button onClick={this.props.closeModal} className="btn btn--round">
              Continue
            </button>
          </div>
        );
    }
  }

  render() {
    return <div>{this.renderModalContent()}</div>;
  }
}

const mapStateToProps = state => {
  return {
    listOfUserNumbers: state.security.listOfUserNumbers,
    isSecurePinValidated: state.security.isSecurePinValidated,
    getListOfUserNumbersError: state.security.listOfUserNumbersError,
    sendSecurePinError: state.security.sendSecurePinError,
    confirmSecurePinError: state.security.confirmSecurePinError,
    addManagerError: state.accManagerReducer.addManagerError,
    addedManager: state.accManagerReducer.addedManager,
    approveManagerError: state.accManagerReducer.approveManagerError,
    managers: state.accManagerReducer.managers,
    enhancedAuthData: state.enhancedAuth.enhancedEdit,
    confirmSecurePinAttempts: state.security.confirmSecurePinAttempts,
    manageSecurePinStarted: state.accManagerReducer.manageSecurePinStarted,
    selectedPhone: state.security.smartPinMtn,
    fetchingManageAccount: state.accManagerReducer.fetchingManageAccount
  };
};

export default connect(
  mapStateToProps,
  {
    getSecretPinStatus,
    getListOfUserNumbers,
    sendSecurePinToPhone,
    confirmSecurePinCode
  }
)(SecurePin);
