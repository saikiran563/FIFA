import React from "react";
import Spinner from "../../Spinner/Spinner";

const ListOfAccountNumbersModal = props => {
  const SMSCapableDevices = props.afterGetRequest.filter(
    mdn => mdn.securePinEligible
  );
  if (SMSCapableDevices.length >= 1) {
    return (
      <div>
        <h1 className="title title--lg">
          Which device should we send the code to?
        </h1>
        <p>
          For the security of your account, we ask that you complete an online
          authorization step before you continue with your request.
        </p>
        {props.fetchingSecurePin ? <Spinner /> : ""}
        <fieldset>
          <legend>
            Select the device where we can send you the online authorization
            code.
          </legend>
          {props.afterGetRequest.map(item => {
            if (item.securePinEligible) {
              return (
                <p key={item.formattedMtn}>
                  <label>
                    <input
                      type="radio"
                      value={item.picked || false}
                      onChange={props.handleRadioInputChange}
                      name={"phone-numbers"}
                      id={item.mtn}
                      checked={item.picked || false}
                      analyticstrack="securepin-selectradio"
                    />
                    <span>{item.formattedMtn.split("-").join(".")}</span>
                  </label>
                </p>
              );
            }
          })}
        </fieldset>
        <button
          className="btn btn--round"
          disabled={!props.selectedPhone}
          style={{ marginRight: "10px" }}
          onClick={props.sendCodeToPhoneHandler}
          analyticstrack="securepin-sendcode"
        >
          Send Code
        </button>
        <button
          className="btn btn--round-invert"
          onClick={props.closeModal}
          style={{ cursor: "pointer" }}
          analyticstrack="securepin-cancel"
        >
          Cancel
        </button>
        {props.sendSecurePinError ? (
          <p
            style={{ marginTop: "10px", marginBottom: "0" }}
            className="errorDisplay"
          >
            <span className="fa fa-exclamation-circle" />
            {props.sendSecurePinError}
          </p>
        ) : (
          ""
        )}
      </div>
    );
  } else {
    return (
      <div>
        <p>
          For your security, both new accounts as well as accounts with recent
          changes are not able to complete this transaction until 7 days have
          passed since the account has been established or since the last
          account change has been made.
        </p>
        <p>
          Please return to My Verizon after 7 days to complete this transaction.
          If you think this message is in error, please contact 800-922-0204.
        </p>
        <button
          className="btn btn--round-invert"
          onClick={props.closeModal}
          style={{ cursor: "pointer" }}
          analyticstrack="securepin-cancel"
        >
          Cancel
        </button>
      </div>
    );
  }
};

export default ListOfAccountNumbersModal;