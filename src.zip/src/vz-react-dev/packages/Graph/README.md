CSS
===

```
.vz-odt--bargraph {
    position: relative;
    width: 100%;
    height: auto;
    text-align: left;
}

.vz-odt--bargraph-label {
    font-size: .875rem;
    margin-bottom: .5rem;
    line-height: .875rem;
}

.vz-odt--bargraph-bar {
    width: 100%;
    height: 8px;
    background-color: #D8D8D8;
}

.vz-odt--bargraph-valuebar {
    width: 0;
    border-bottom-color: #1BAD4C;
    border-bottom-style: solid;
    border-width: 0 0 8px 0;
    transition-duration: 1000ms;
    transition-timing-function: ease-out;
}
```