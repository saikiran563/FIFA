export { default } from "./ErrorBoundary";
