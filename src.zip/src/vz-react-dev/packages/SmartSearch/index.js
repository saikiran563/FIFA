export { default } from './SmartSearchContainer'
