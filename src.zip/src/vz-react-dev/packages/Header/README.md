CSS
===

```
.vz-odt--header__section {
    font-family: "NeueHaasGroteskDisplayBold", Arial, Helvetica, sans-serif;
    font-size: 1.875rem;
    height: 3.5rem;
    display:flex;
    flex-direction: column;
    padding: 0 1.125rem;
    max-width: 79.5rem;
    margin: 0rem auto 1.725rem auto;
}

.vz-odt--header__section_highlight {
    width: 50px;
    margin-top: .7rem;
    border-bottom-color: rgba(213, 43, 30, 1);
    border-bottom-style: solid;
    border-width: 0 0 5px 0;
}




```