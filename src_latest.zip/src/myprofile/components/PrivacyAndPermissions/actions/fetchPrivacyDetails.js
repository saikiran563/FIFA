import mockProfileAPI from "../api";
import axios from "axios";
export const FETCH_PRIVACY_AND_PERMISSIONS_BEGIN =
  "privacies/FETCH_PRIVACY_AND_PERMISSIONS_BEGIN";
export const FETCH_PRIVACY_AND_PERMISSIONS_SUCCESS =
  "privacies/FETCH_PRIVACY_AND_PERMISSIONS_SUCCESS";
export const POST_PRIVACY_PERMISSIONS = "POST_PRIVACY_PERMISSIONS";
const PRIVACY_PERMISSIONS = "PRIVACY_PERMISSIONS";
export const POST_PRIVACY_PERMISSIONS_FAIL = "POST_PRIVACY_PERMISSIONS_FAIL";

export const GET_PRIVACY_ERROR = 'GET_PRIVACY_ERROR'

import  { getURL,encrypt, decrypt, BASE_URL, API_NAME, storedHeaders } from "../../../../utils/config"

const customHeaders = {
  Accept: "application/json"
};
export const fetchPrivacyAndPermissions = () => dispatch => {
  // dispatch(fetchPrivacyAndPermissionsBegin())
  // mockProfileAPI.fetchPrivacyAndPermissions(response => {
  //   dispatch(fetchPrivacyAndPermissionsSuccess(response))
  // })
  // http://www.mocky.io/v2/5b9812592f000074007b3dd2
  // https://vzwqa2.verizonwireless.com/ui/acct/secure/data/secure/profile/privacyPermissions
  axios.get(getURL('GET_PRIVACY_SETTINGS'),storedHeaders())
    .then(response => {
      // response.data.statusCode = "1"
      if(response.data && parseInt(response.data.statusCode) == 0) {
      dispatch(fetchPrivacyAndPermissionsSuccess(response.data));
      }
      else {
        dispatch(getPrivacyError())
        console.log("error")
      }
    })
    .catch((error) => {
      dispatch(getPrivacyError())
    });
};

export const postPrivacyPermissions = privacyData => async dispatch => {
  const newData = JSON.parse(JSON.stringify(privacyData))
  newData.privacySettingItems.map(item => Object.keys(item.mtnSettingsMap).map(key => {
    return delete Object.assign(item.mtnSettingsMap, {[key.split(",")[1].split("encryptedMdn=")[1].split(")")[0]]: item.mtnSettingsMap[key] })[key];
  }))
  const response = await axios.post(getURL('POST_PRIVACY_SETTINGS'),
    newData,
    {
      headers: {
        "Content-Type": "application/json"
      }
    }
  );
  if(response.data.statusCode == 0){
    dispatch({
      type: POST_PRIVACY_PERMISSIONS,
      payload: privacyData
    });
  } else {
    dispatch({
      type: POST_PRIVACY_PERMISSIONS_FAIL,
      payload: response.data.errorCode
    });
  }
};

export const fetchPrivacyAndPermissionsBegin = () => ({
  type: FETCH_PRIVACY_AND_PERMISSIONS_BEGIN
});
export const fetchPrivacyAndPermissionsSuccess = payload => ({
  type: FETCH_PRIVACY_AND_PERMISSIONS_SUCCESS,
  payload
});

export const getPrivacyError = error => ({
  type: GET_PRIVACY_ERROR,
  error
});