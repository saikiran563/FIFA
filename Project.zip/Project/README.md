# One Digital React POC

##### Running for development

     npm start
