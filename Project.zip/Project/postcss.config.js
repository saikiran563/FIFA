module.exports = {
  plugins: [
    require('postcss-media-variables'),
    require('postcss-css-variables'),
    require('postcss-custom-media'),
    require('autoprefixer')
  ]
};
