import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Link, NavLink, withRouter } from 'react-router-dom';
import { bindActionCreators } from 'redux'
import * as actions from './actions'
import Spinner from "../Spinner/Spinner";
import Modal from '../Modal/modal'
import PhoneVerificationNeeded from "./views/PhoneVerificationNeeded";
import EmailVerificationNeeded from "./views/EmailVerificationNeeded";
import SecurePin from "../SecurePin/SecurePin"
import { getErrorMsgByCode } from "../../../utils/config"

import './style.css'

class EnhancedAuth extends Component {
    constructor(props) {
        super(props)
        this.state = {
            modalStatus: false,
            radioselected: '',
            verifyEmailClicked: false,
            radioClicked:false,
            enauthSaved: false,
            securePinModal: false,
            enhancedAuthSaved: false
        }
    }

    selectRadio = (e) => {
        this.setState({radioClicked:true})
        let selectedRadio = document.querySelectorAll('.enhanced-auth .radio_table input:checked')[0].value;
       
        this.setState({ radioselected: document.querySelectorAll('.enhanced-auth .radio_table input:checked')[0].value });
    }

    saveChangesClickedHandler = (event) => {
        this.props.actions.getSecretPinStatus().then(() => {
          const { securePin } = this.props;
          console.log(securePin);
          if (!this.props.securePinError) {
            if (!securePin.securePinEnabled) {
              console.log("secure pin not enabled");
              return this.handleSave()
            //   return this.props.handleSave(
            //     "questionForm",
            //     {
            //       challengeQuestionID: this.state.newQId,
            //       challengeAnswer: this.state.newAnswer
            //     },
            //     event
            //   );
            }
            if (!securePin.securePinVerified) {
              console.log("secure pin not verified, go through secure pin flow");
              this.props.actions.getListOfUserNumbers().then(() => {
                this.setState({
                  securePinModal: true,
                  listOfAccountNumbersModal: true,
                });
              });
            } else {
              console.log("secure pin already verified");
              return this.handleSave()
            //   return this.props.handleSave(
            //     "questionForm",
            //     {
            //       challengeQuestionID: this.state.newQId,
            //       challengeAnswer: this.state.newAnswer
            //     },
            //     event
            //   );
            }
          } else {
            this.setState({
              errorModal: true
            });
          }
        });
      };

    verifyModal = (e) => {
        this.setState({
            modalStatus: true,
        })
        if (!this.props.enhancedAuthFlag.verifyemail) {
            let enauth = this.props.enhancedAuthFlag.enhancedEdit;
            let flag = "1"
            this.props.actions.verifyEmail(flag, enauth.email, enauth.mdn, enauth.mdn_is_capable, enauth.cust_id, enauth.acct_num, enauth.user_id, enauth.role);
        }
        else {
            this.setState({
                modalStatus: false,
            })
            this.props.actions.fetchEnhAuthEdit();       
            // this.props.actions.fetchEnhAuthEdit();
        }
        this.setState({radioClicked:false})
    }

    reverifyModal = () => {
        this.setState({
            modalStatus: true,
        })
        let enauth = this.props.enhancedAuthFlag.enhancedEdit;
        let flag = "1"
        this.props.actions.verifyEmail(flag, enauth.email, enauth.mdn, enauth.mdn_is_capable, enauth.cust_id, enauth.acct_num, enauth.user_id, enauth.role);  
    }

    closeModal = () => {
        this.props.actions.clearErrorCodes()
        this.props.actions.clearEnhancedAuthErrors()
        this.setState({
            modalStatus: false,
            verifyEmailClicked: true,
            securePinModal: false
        });
        this.props.actions.resetverifyEmailStatus(null);
    }

    handleSave = () => {
        let enauth = this.props.enhancedAuthFlag.enhancedEdit;
        let flag = document.querySelectorAll('.enhanced-auth .radio_table input:checked')[0].value;
        this.props.actions.setEnhancedAuth(flag, enauth.email, enauth.mdn, enauth.email_is_verified, enauth.mdn_is_capable, enauth.cust_id, enauth.acct_num, enauth.user_id, enauth.role);
        this.props.handleSave("enhancedForm", "", event);
        this.setState({radioClicked:false})
    }
updateRadio=() => {
    if (!this.props.showEnhancedAuthEdit && this.props.enAuthEditMode && document.querySelectorAll('.enhanced-auth .radio_table input').length) {
        this.props.enhancedAuthFlag.enhancedEdit && this.props.enhancedAuthFlag.enhancedEdit.two_factor_flag != '0' ?
            document.querySelectorAll('.enhanced-auth .radio_table input')[0].checked = true :
            document.querySelectorAll('.enhanced-auth .radio_table input')[1].checked = true;
        // this.setState({radioselected:document.querySelectorAll('.enhanced-auth .radio_table input:checked')[0].value});
    }
}

    componentWillReceiveProps(nextProps) {
        if(this.state.enhancedAuthSaved){
            if(nextProps.event != this.props.event){
                this.setState({
                    enhancedAuthSaved: false
                })
            }
        }
        if(nextProps.enhancedAuthFlag.setenhancedAuth != this.props.enhancedAuthFlag.setenhancedAuth){
            this.setState({
                enhancedAuthSaved: true
            })
        }
        let that = this;
       document.querySelectorAll('.enhanced-auth .radio_table input').length == 0   ?

            setTimeout(function () {
                !that.state.radioClicked && that.updateRadio()
            }, 150) :    !that.state.radioClicked && that.updateRadio();
           
    }

    // componentWillUpdate(prevProps) {
    //     if(prevProps.enhancedAuthData != this.props.enhancedAuthData){
    //         return this.setState({
    //             enauthSaved: true
    //         })
    //     }
    // }

    componentDidMount() {
        let that = this;
        
        document.querySelectorAll('.enhanced-auth .radio_table input').length==0 ?
        
        setTimeout(function(){
            that.updateRadio()},150)     :that.updateRadio();
    
        }
    mobileNumberFormat = (s) => {
        var s2 = ("" + s).replace(/\D/g, '');
        var m = s2.match(/^(\d{3})(\d{3})(\d{4})$/);
        return (!m) ? null : m[1] + "-" + m[2] + "-" + m[3];
    }

    render() {
        // console.log("ENHANCEDAUTHDATA", this.props.enhancedAuthData)
        const { passwordEditMode, showUserEdit, userEditMode, enAuthEditMode, accountPinEditMode, questionEditMode, showEnhancedAuthEdit, enauthStatus } = this.props;
        let enauth = this.props.enhancedAuthFlag.enhancedEdit;
        // this.props.enhancedAuthFlag.enhancedEdit = null;
        let enauthview = this.props.twoFactor;
        let radioButtonselect = this.state.radioselected == '1';

        let initialEmail = this.props.enhancedAuthFlag.enhancedEdit ? this.props.enhancedAuthFlag.enhancedEdit.email : "";
        // let newEmail = "VZW@VZW.COM";
        let newEmail ;
        let disableflag = true;
        initialEmail!=newEmail && (newEmail=initialEmail, disableflag=false);

        let swicthOffFlag = this.props.metaBlock && this.props.metaBlock.twoFactorFlag && this.props.enhancedAuthData ==null?this.props.metaBlock.twoFactorFlag: (this.props.enhancedAuthData && this.props.enhancedAuthData.two_factor_flag)
        console.log("TwoFactorFlag", swicthOffFlag)
        
        const editableClassName = enAuthEditMode ? "description_box--edit-view" : "description_box_disabled";
        return (


            <div className={`aMyProfile__privacy row enhanced_auth description_box ${editableClassName}   ${!showEnhancedAuthEdit && enAuthEditMode && 'enhanced_edit'}`} >
                <div className="col-xs-12 col-sm-4 description_box__header">
                    <h4>Enhanced authentication</h4>
                    <p>Protect your account with added level of security.</p>
                </div>

                 {!showEnhancedAuthEdit && enAuthEditMode &&
                                <div className="description_box__edit description_box__edit_section col-sm-2 description_box__edit description_box__edit_section cancel">
                                    <a className="btn btn-anchor" onClick={() => this.props.handleEditCancel('cancelblock')} role="button" href="#/security" >Cancel</a>
                                </div>
                            }

                <div className="col-xs-12 col-sm-8 description_box__large-container">
                    <div className="row">
                        <div className="col-xs-12 description_box__details enhanced-auth">
                            {!(!showEnhancedAuthEdit && enAuthEditMode) && <div className="description_box__read">
                                {swicthOffFlag == '1' ? <p>ON</p> : <p>OFF</p>}
                            </div>}
                           

                            {
                                !showEnhancedAuthEdit && enAuthEditMode &&
                                <div>
                                   <div className="row"> <p className="col-xs-3">Protect your account with another level of security. When enabled, the account, and all users will be protected by two-factor authentication (a one-time code sent to your phone) each time the user signs in to My Verizon or calls Verizon</p> 
                                   <p className="col-xs-3">Please note that if you are unable to receive this one-time code or forget your Account PIN, you will need to visit a Verizon Wireless store with valid ID. To disable this feature, sign in to My Verizon and change the setting on the Profile page.</p> </div>
                                    {((((!showEnhancedAuthEdit && enAuthEditMode))
                                      && enauth && ((enauth.email_is_verified == 'Y' && enauth.mdn_is_capable == 'Y') || this.state.radioselected != "1"))) &&
                                        (
                                             !Object.keys(this.props.enhancedAuthFlag.enhancedEdit).length ? <Spinner/> : <div className="enhancedauth">
                                                <div> <div className="radio_table">
                                                    <div className="row">
                                                        <div className="col-xs-6 radio_table__header"></div>
                                                        <div className="col-xs-3"><p className="radio_table__share">On</p></div>
                                                        <div className="col-xs-3"><p className="radio_table__share">Off</p></div>
                                                    </div>
                                                    <div className="row">
                                                        <div className="col-xs-6 radio_table__header">Require Enhanced Authentication</div>
                                                        <div className="col-xs-3">
                                                            <input aria-labelledby="share-insight-use-0-label" analyticstrack="enhancedauth-On" id="radio6" type="radio" value="1" name="radio4"  onChange={this.selectRadio} onClick= {this.selectRadio} />
                                                        </div>
                                                        <div className="col-xs-3">
                                                            <input aria-labelledby="share-insight-dontuse-0-label" analyticstrack="enhancedauth-Off" id="radio7" type="radio" value="0" name="radio4" onChange={this.selectRadio} onClick= {this.selectRadio} />
                                                        </div>
                                                    </div>
                                                </div>
                                                </div>
                                            </div>)
                                    }

                                    {/* Case 1: Both Email and Mobile Verified */}
                                   { !this.props.enhancedAuthFlag.enhancedEdit ? <Spinner/> :  <div>   {((enauth && enauth.two_factor_flag == '1' || radioButtonselect && enauth.email_is_verified == 'Y' && enauth.mdn_is_capable == 'Y')) &&

                                       <div className="row">
                                            {(this.state.radioselected != "0"||(enauth && enauth.two_factor_flag == '1' && !this.state.radioClicked)) && <div className="userbio">
                                                <div> <p className="col-xs-6" style={{ marginBottom: 25, marginTop: -10 }}>When logging in or calling customer care you will be able to choose from the following options to verify your identity</p> </div>
                             
                                                <div className="col-xs-6 radio_table__header ">Email</div> <div className="col-xs-3 email"> <p>{enauth.email}</p> </div>
                                                <div className='col-xs-3 edit'> <p><a href='#/contactbilling/email' analyticstrack="enhancedauth-editemail" className="btn btn-anchor" role="button" tabIndex="0">Edit</a></p> </div>
                                                <div className="col-xs-6 radio_table__header textmessage">Text Message</div> <div className="col-xs-3 mobile"> <p>{this.mobileNumberFormat(enauth.mdn)}</p> </div>
                                               
                                {/* { enauth.push_enabled == 'Y' ? (<div> <div className="col-xs-6 radio_table__header textmessage">Mobile Notification</div> <div className="col-xs-3 pushmobile"> <p>{this.mobileNumberFormat(enauth.pushmdn)}</p> </div> </div>) : <div><p style={{marginTop:14}} className="col-xs-6">How can I get more methods for verification?</p> </div> } */}

                                            </div>}

                                            <div className="footer col-xs-12">
                                                <a className="btn btn--round-invert" analyticstrack="enhancedauth-cancel" role="button" onClick={() => this.props.handleEditCancel('cancelblock')} href="#/security" >Cancel</a>
                                                <button className="btn btn--round" analyticstrack="enhancedauth-savechanges" disabled={disableflag && this.props.enhancedAuthFlag.enhancedEdit.two_factor_flag=='1' && this.state.radioselected != "0"} onClick={this.saveChangesClickedHandler}>Save Changes</button>
                                            </div>
                                        </div> }

                                         { ((enauth && enauth.two_factor_flag == '0' && !radioButtonselect )) && <div className="footer col-xs-12">
                                                <a className="btn btn--round-invert" analyticstrack="enhancedauth-cancel" role="button" onClick={() => this.props.handleEditCancel('cancelblock')} href="#/security" >Cancel</a>
                                                <button className="btn btn--round" analyticstrack="enhancedauth-savechanges" disabled={enauth.two_factor_flag == '0'}>Save Changes</button>
                                </div> }

                                   </div> }

                                    {/* Case 2: Both Email and Mobile Not Verified */}
                                    {(
                                        (radioButtonselect && enauth.two_factor_flag == '0' && enauth.mdn_is_capable == 'N' && enauth.email_is_verified == 'N')) &&
                                        (
                                            <div>
                                                   {this.props.enhancedAuthFlag.verifyemail && this.props.enhancedAuthFlag.isFetching ?<Spinner/> :
                                                <EmailVerificationNeeded emailAddress={enauth.email} verifyEmailClicked={this.state.verifyEmailClicked} verifyModal={this.verifyModal} reverifyModal={this.reverifyModal} handleEditCancel={this.props.handleEditCancel} />
                                                   }
                                                <div className="row"> <hr /> </div>
                                                <PhoneVerificationNeeded mobileNumber={this.mobileNumberFormat(enauth.mdn)} handleEditCancel={this.props.handleEditCancel} />
                                                { this.props.verifyEmailStatus=='00' && <Modal
                                                    modalStatus={this.state.modalStatus}
                                                    closeModal={this.closeModal}
                                                    tagId="enhancedauth_verifyemail">
                                                    <p><strong>Email Verification Sent</strong></p>
                                                    <p>We've sent you an email. When you receive it, open it and click the "verify" button to confirm your email address.</p>
                                                    <p>It's important to complete this step in order to protect the privacy of your account to make sure we're sending information to the right place.</p>
                                                    <div className="footer col-xs-12">
                                                        <button className="btn btn--round" onClick={this.closeModal}>Close</button>
                                                    </div>
                                                </Modal> }
                                            </div>
                                        )}


                                    {/* Case 3: Email Verified and Mobile Not Verified */}
                                    {(
                                        (radioButtonselect && this.props.enhancedAuthFlag.enhancedEdit.email_is_verified == 'Y' && this.props.enhancedAuthFlag.enhancedEdit.mdn_is_capable == 'N')) &&
                                        (
                                            <PhoneVerificationNeeded mobileNumber={this.mobileNumberFormat(enauth.mdn)} handleEditCancel={this.props.handleEditCancel} />
                                        )}


                                    {/* Case 4: Email NotVerified and Mobile Verified */}
                                    {(
                                        (radioButtonselect && this.props.enhancedAuthFlag.enhancedEdit.email_is_verified == 'N' && this.props.enhancedAuthFlag.enhancedEdit.mdn_is_capable == 'Y')) &&
                                        (
                                            <div>
                                                
                                                             {this.props.enhancedAuthFlag.verifyemail && this.props.enhancedAuthFlag.isFetching ?<Spinner/> :
                                                <EmailVerificationNeeded emailAddress={enauth.email} verifyEmailClicked={this.state.verifyEmailClicked} verifyModal={this.verifyModal} reverifyModal={this.reverifyModal} handleEditCancel={this.props.handleEditCancel}/>
                                                
                                                }
                                              { this.props.verifyEmailStatus=='00' && <Modal
                                                    modalStatus={this.state.modalStatus}
                                                    closeModal={this.closeModal}>
                                                    <p style={{ fontSize: 14 }} ><strong>Email Verification Sent</strong></p>
                                                    <p>We've sent you an email. When you receive it, open it and click the "verify" button to confirm your email address.</p>
                                                    <p>It's important to complete this step in order to protect the privacy of your account to make sure we're sending information to the right place.</p>
                                                    <div className="footer col-xs-12">
                                                        <button className="btn btn--round" onClick={this.closeModal}>Close</button>
                                                    </div>
                                              </Modal> }
                                            </div>
                                        )}
                                </div>
                            }
                        </div>
                        {showEnhancedAuthEdit && <div className="description_box__edit description_box__edit_section">
                        <a className="btn btn-anchor" analyticstrack="enhancedauth-edit" role="button" href="#/security/enhancedauth" onClick={() => this.props.handleEditCancel('enhancedauthblock')}  >Edit</a>
                        </div>}

                        {
                            this.state.enhancedAuthSaved && <span className="text-success fa fa-check-circle col-xs-12 section-saved"> Saved </span>
                        }

                    </div>
                </div>
                <Modal modalStatus={this.state.securePinModal} closeModal={this.closeModal} tagId="enhancedauth-securepin" >
                    <SecurePin
                        handleSaveType={"enhancedAuth"}
                        // handleSaveData={"afasd"}
                        handleSave={this.handleSave}
                        closeModal={this.closeModal}
                     />
                </Modal>
                    <Modal modalStatus={this.props.enhancedAuthError} closeModal={this.closeModal} tagId="enhancedauth-error" >
                    {getErrorMsgByCode(this.props.enhancedAuthError)}
                </Modal>
                <Modal modalStatus={this.props.securePinError} closeModal={this.closeModal} tagId="enhancedauth-securepin-error" >
                    {getErrorMsgByCode(this.props.securePinError)}
                </Modal>
            </div>


        )
    }
}

const mapStateToProps = state => {
    // console.log("STATE VALUES", state);
    return {
        isFetching: state.enhancedAuth.isFetching,
        twoFactorAuth: state.enhancedAuth.enhancedEdit,
        enhancedAuthFlag: state.enhancedAuth,
        twoFactor: state.security.metaData,
        enauthStatus: state.enhancedAuth.enauthStatus,
        verifyEmailStatus: state.enhancedAuth.verifyEmailStatus,
        securePin: state.security.secretPin,
        enhancedAuthError: state.enhancedAuth.enhancedAuthError,
        securePinError: state.security.securePinError,
        enhancedAuthData: state.enhancedAuth.setenhancedAuth
    }
}

const mapDispatchToProps = dispatch => ({
    actions: bindActionCreators(actions, dispatch),
})


export default connect(mapStateToProps, mapDispatchToProps)(EnhancedAuth)  
