import React, { Component } from 'react'
import './loader.css';



const Spinner = () => {
  return (
    // <div className="loader">Loading...</div>
    <div className="Loader"></div>
  )
}



export default Spinner
